# ProfZoom OTP Bot

OTP_bot is a delivery and Telegram-linking service. It MUST NOT generate, verify, or store OTP codes. It only sends provided OTP codes to Telegram chats and manages Telegram account linking.

## Responsibilities

- Delivery-only OTP sending via Telegram.
- Telegram linking flow (register token, link via /start, status checks).
- Single HTTP server exposes all endpoints on one base URL: `/telegram/webhook`, `/telegram/link-token`, `/telegram/status`, `/otp/send`, `/health`.

## Environment

Required:

```
TELEGRAM_BOT_TOKEN=replace_me
OTP_BOT_INTERNAL_KEY=replace_me
```

Optional (defaults shown):

```
DATABASE_URL=postgres://user:pass@localhost:5432/profzoom?sslmode=disable
DB_DRIVER=pgx
TELEGRAM_WEBHOOK_SECRET=replace_me
TELEGRAM_LINK_TTL=10m
LINK_TOKEN_RATE_LIMIT_PER_MIN=5
LINK_TOKEN_RATE_LIMIT_IP_PER_MIN=5
LINK_TOKEN_RATE_LIMIT_BOT_PER_MIN=5
PORT=8080
LOG_LEVEL=info
TELEGRAM_TIMEOUT=5s
OTP_RATE_LIMIT_PER_MIN=2
OTP_RATE_LIMIT_IP_PER_MIN=2
OTP_RATE_LIMIT_BOT_PER_MIN=60
```

Per-IP/per-bot rate limits default to their existing per-minute settings when omitted.
`TELEGRAM_LINK_TTL` must be between 5m and 10m.
If `DATABASE_URL` is unset, the service uses in-memory stores.

## Migrations

Run the SQL in the `migrations/` directory against your Postgres database.
Tables used by this service: `telegram_links`, `telegram_link_tokens`.
`telegram_links` is owned by this service; if the main backend mirrors it, keep schemas synchronized.

## HTTP endpoints

OpenAPI specification is available at `openapi.yaml`.

### POST /otp/send

Delivery-only OTP send endpoint.

Headers:

```
X-Internal-Key: ${OTP_BOT_INTERNAL_KEY}
```

Body:

```
{ "phone": "+15551234567", "code": "834291" }
```

Constraints:

- `phone` must be linked.
- `code` must be non-empty.
- Telegram message is sent as: `ProfZoom login code: <code>`.

Responses:

- `200` `{ "sent": true }`
- `400` `{ "error": "invalid_payload" }` or `{ "error": "phone_not_linked" }`
- `401` `{ "error": "unauthorized" }`
- `429` `{ "error": "rate_limited" }`
- `500` `{ "error": "telegram_failed" }`

### POST /telegram/link-token

Register a one-time Telegram linking token.

Headers:

```
X-Internal-Key: ${OTP_BOT_INTERNAL_KEY}
```

Body:

```
{ "phone": "+15551234567", "token": "..." }
```

Response:

```
{ "success": true }
```

### GET /telegram/status

Return Telegram link status for a phone number.

Headers:

```
X-Internal-Key: ${OTP_BOT_INTERNAL_KEY}
```

Query:

```
/telegram/status?phone=+15551234567
```

Body (optional):

```
{ "phone": "+15551234567" }
```

Responses:

Linked:

```
{ "linked": true }
```

Not linked:

```
{ "linked": false }
```

### POST /telegram/webhook

Telegram webhook endpoint.

Headers:

```
X-Telegram-Bot-Api-Secret-Token: ${TELEGRAM_WEBHOOK_SECRET}
```

Supports `/start <token>`, `/help`, `/status`, and contact sharing in private chats.

### GET /health

Health check endpoint.

Response:

```
{ "status": "ok" }
```

## Linking flow

1. Main backend calls `GET /telegram/status?phone=...`.
2. If not linked, main backend calls `POST /telegram/link-token` with `{ phone, token }`.
3. App builds a Telegram deep link: `/start <token>` and sends it to the user.
4. User opens the link in Telegram; OTP_bot handles `/telegram/webhook` and links the chat to the phone.
5. Main backend calls `GET /telegram/status?phone=...` again and then `POST /otp/send`.

Users can also link by sharing their Telegram contact with the bot in a private chat.

## Run locally

```
go run ./cmd/server
```

## CI

```
go test ./...
```

package linking

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"
)

// LinkToken represents a short-lived token to link Telegram chat IDs.
type LinkToken struct {
	TokenHash []byte
	UserID    string
	Phone     string
	ExpiresAt time.Time
}

// LinkTokenStore persists verification tokens.
type LinkTokenStore interface {
	Save(ctx context.Context, token LinkToken) error
	Consume(ctx context.Context, tokenHash []byte) (LinkToken, error)
}

// ErrLinkTokenNotFound indicates invalid or expired token.
var ErrLinkTokenNotFound = errors.New("link token not found")

// MemoryLinkTokenStore stores tokens in memory.
type MemoryLinkTokenStore struct {
	mu     sync.Mutex
	tokens map[string]LinkToken
}

// NewMemoryLinkTokenStore builds an in-memory token store.
func NewMemoryLinkTokenStore() *MemoryLinkTokenStore {
	return &MemoryLinkTokenStore{tokens: make(map[string]LinkToken)}
}

func (s *MemoryLinkTokenStore) Save(_ context.Context, token LinkToken) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	for key, stored := range s.tokens {
		if stored.Phone == token.Phone {
			delete(s.tokens, key)
		}
	}
	s.tokens[hexToken(token.TokenHash)] = token
	return nil
}

func (s *MemoryLinkTokenStore) Consume(_ context.Context, tokenHash []byte) (LinkToken, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	stored, ok := s.tokens[hexToken(tokenHash)]
	if !ok {
		return LinkToken{}, ErrLinkTokenNotFound
	}
	delete(s.tokens, hexToken(tokenHash))
	if time.Now().After(stored.ExpiresAt) {
		return LinkToken{}, ErrLinkTokenNotFound
	}
	return stored, nil
}

// TelegramLink holds the relationship between a phone and a Telegram chat.
type TelegramLink struct {
	UserID         string
	Phone          string
	TelegramChatID int64
	VerifiedAt     time.Time
}

// TelegramLinkStore persists phone-to-chat associations.
type TelegramLinkStore interface {
	GetByPhone(ctx context.Context, phone string) (TelegramLink, error)
	GetByUserID(ctx context.Context, userID string) (TelegramLink, error)
	GetByChatID(ctx context.Context, chatID int64) (TelegramLink, error)
	LinkChat(ctx context.Context, link TelegramLink) error
}

// ErrTelegramLinkNotFound indicates missing chat association.
var ErrTelegramLinkNotFound = errors.New("telegram link not found")

// MemoryTelegramLinkStore keeps links in memory.
type MemoryTelegramLinkStore struct {
	mu    sync.RWMutex
	links map[string]TelegramLink
	users map[string]TelegramLink
	chats map[int64]TelegramLink
}

// NewMemoryTelegramLinkStore creates an in-memory link store.
func NewMemoryTelegramLinkStore() *MemoryTelegramLinkStore {
	return &MemoryTelegramLinkStore{
		links: make(map[string]TelegramLink),
		users: make(map[string]TelegramLink),
		chats: make(map[int64]TelegramLink),
	}
}

func (s *MemoryTelegramLinkStore) GetByPhone(_ context.Context, phone string) (TelegramLink, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	link, ok := s.links[phone]
	if !ok {
		return TelegramLink{}, ErrTelegramLinkNotFound
	}
	return link, nil
}

func (s *MemoryTelegramLinkStore) GetByUserID(_ context.Context, userID string) (TelegramLink, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	link, ok := s.users[userID]
	if !ok {
		return TelegramLink{}, ErrTelegramLinkNotFound
	}
	return link, nil
}

func (s *MemoryTelegramLinkStore) GetByChatID(_ context.Context, chatID int64) (TelegramLink, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	link, ok := s.chats[chatID]
	if !ok {
		return TelegramLink{}, ErrTelegramLinkNotFound
	}
	return link, nil
}

func (s *MemoryTelegramLinkStore) LinkChat(_ context.Context, link TelegramLink) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if existing, ok := s.users[link.UserID]; ok {
		delete(s.links, existing.Phone)
		delete(s.chats, existing.TelegramChatID)
	}
	if existing, ok := s.links[link.Phone]; ok {
		delete(s.chats, existing.TelegramChatID)
		delete(s.users, existing.UserID)
	}
	if existing, ok := s.chats[link.TelegramChatID]; ok {
		delete(s.links, existing.Phone)
		delete(s.users, existing.UserID)
	}
	s.links[link.Phone] = link
	s.users[link.UserID] = link
	s.chats[link.TelegramChatID] = link
	return nil
}

func hexToken(hash []byte) string {
	return fmt.Sprintf("%x", hash)
}

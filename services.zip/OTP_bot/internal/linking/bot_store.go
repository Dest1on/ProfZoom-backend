package linking

import (
	"context"
	"errors"
	"time"

	"github.com/profzoom/otp_bot/internal/telegram"
)

// BotLinkStore adapts TelegramLinkStore for bot usage.
type BotLinkStore struct {
	store TelegramLinkStore
	clock func() time.Time
}

// NewBotLinkStore creates a bot-facing link store adapter.
func NewBotLinkStore(store TelegramLinkStore) *BotLinkStore {
	return &BotLinkStore{
		store: store,
		clock: time.Now,
	}
}

// GetByPhone returns a link by phone.
func (s *BotLinkStore) GetByPhone(ctx context.Context, phone string) (telegram.LinkInfo, error) {
	link, err := s.store.GetByPhone(ctx, phone)
	if err != nil {
		if errors.Is(err, ErrTelegramLinkNotFound) {
			return telegram.LinkInfo{}, telegram.ErrLinkNotFound
		}
		return telegram.LinkInfo{}, err
	}
	return telegram.LinkInfo{Phone: link.Phone, ChatID: link.TelegramChatID}, nil
}

// GetByChatID returns a link by chat ID.
func (s *BotLinkStore) GetByChatID(ctx context.Context, chatID int64) (telegram.LinkInfo, error) {
	link, err := s.store.GetByChatID(ctx, chatID)
	if err != nil {
		if errors.Is(err, ErrTelegramLinkNotFound) {
			return telegram.LinkInfo{}, telegram.ErrLinkNotFound
		}
		return telegram.LinkInfo{}, err
	}
	return telegram.LinkInfo{Phone: link.Phone, ChatID: link.TelegramChatID}, nil
}

// LinkChat links a phone with a chat ID.
func (s *BotLinkStore) LinkChat(ctx context.Context, phone string, chatID int64) error {
	link := TelegramLink{
		UserID:         phone,
		Phone:          phone,
		TelegramChatID: chatID,
		VerifiedAt:     s.clock(),
	}
	return s.store.LinkChat(ctx, link)
}

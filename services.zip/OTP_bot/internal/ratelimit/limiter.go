package ratelimit

import (
	"sync"
	"time"
)

// Limiter enforces a maximum number of actions per key within a window.
type Limiter interface {
	Allow(key string) bool
}

// NoopLimiter allows everything.
type NoopLimiter struct{}

// Allow always returns true.
func (NoopLimiter) Allow(string) bool { return true }

type bucket struct {
	count     int
	resetTime time.Time
}

// MemoryLimiter enforces a fixed window rate limit in memory.
type MemoryLimiter struct {
	limit  int
	window time.Duration
	mu     sync.Mutex
	items  map[string]bucket
}

// NewMemoryLimiter creates a limiter with the given limit per window.
func NewMemoryLimiter(limit int, window time.Duration) *MemoryLimiter {
	return &MemoryLimiter{
		limit:  limit,
		window: window,
		items:  make(map[string]bucket),
	}
}

// Allow returns true when the key is within the allowed rate.
func (l *MemoryLimiter) Allow(key string) bool {
	if l == nil {
		return true
	}
	if l.limit <= 0 {
		return true
	}

	now := time.Now()
	l.mu.Lock()
	defer l.mu.Unlock()

	state, ok := l.items[key]
	if !ok || now.After(state.resetTime) {
		state = bucket{count: 0, resetTime: now.Add(l.window)}
	}

	if state.count >= l.limit {
		l.items[key] = state
		l.cleanupLocked(now)
		return false
	}

	state.count++
	l.items[key] = state
	l.cleanupLocked(now)
	return true
}

func (l *MemoryLimiter) cleanupLocked(now time.Time) {
	if len(l.items) < 2000 {
		return
	}
	for key, state := range l.items {
		if now.After(state.resetTime) {
			delete(l.items, key)
		}
	}
}

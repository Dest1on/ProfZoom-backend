package otpbot

type Status struct {
	Linked bool `json:"linked"`
}

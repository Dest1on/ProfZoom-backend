# ProfZoom API

Main service is the single source of truth for authorization. It generates OTPs, stores only hashes, verifies OTPs, decides auth, and issues JWT/refresh tokens. OTP delivery is handled exclusively by OTP_bot.

## Auth flow

- `POST /auth/send-code` with `{ "phone": "+79991234567" }`
  - Generates OTP and stores hash with TTL and attempts left.
  - Checks Telegram binding via OTP_bot.
  - If Telegram is not linked, registers a link token and returns `need_link`.
  - Sends OTP via OTP_bot.
  - Response when link is needed: `{ "success": false, "need_link": true, "telegram_token": "<token>", "telegram_link": "https://t.me/ProfZoomOtpBot?start=<token>" }`
- `POST /auth/verify-code` with `{ "phone": "+79991234567", "code": "123456" }`
  - Verifies OTP hash and issues access + refresh tokens.
  - Response: `{ "token": "<access_jwt>", "refresh_token": "<refresh>", "is_new_user": true }`

## OTP_bot integration

- `GET /telegram/status?phone=+79991234567` with header `X-Internal-Key: $OTP_BOT_INTERNAL_KEY`
  - 200 linked: `{ "linked": true }`
  - 200 not linked: `{ "linked": false }`
- `POST /telegram/link-token` with `{ "phone": "+79991234567", "token": "<token>" }`
  - Auth header: `X-Internal-Key: $OTP_BOT_INTERNAL_KEY`
- `POST /otp/send` with `{ "phone": "+79991234567", "code": "123456" }`
  - Auth header: `X-Internal-Key: $OTP_BOT_INTERNAL_KEY`
- The service does not store Telegram `chat_id`; it fetches status per request.

## Tokens and sessions

- Access JWT includes `sub` (user_id), `roles`, `exp`, `iat`.
- Refresh tokens are stored hashed, rotated on refresh, and revoked on logout.

## Roles

- `student`, `company`
- Role checks enforced by middleware.
- Role is selected later via `PATCH /users/role` with `{ "role": "student" | "company" }`.

## Environment

Required:
- `DATABASE_URL`
- `JWT_SECRET`
- `OTP_BOT_BASE_URL`
- `OTP_BOT_INTERNAL_KEY`

Optional:
- `HTTP_PORT` (default `8080`)
- `ACCESS_TOKEN_TTL` (default `15m`)
- `REFRESH_TOKEN_TTL` (default `720h`)
- `OTP_TTL` (default `2m`)
- `DB_MAX_OPEN_CONNS` (default `25`)
- `DB_MAX_IDLE_CONNS` (default `10`)
- `DB_CONN_MAX_IDLE` (default `5m`)
- `DB_CONN_MAX_LIFE` (default `30m`)
- `REQUEST_TIMEOUT` (default `10s`)
- `OTP_BOT_TELEGRAM_USERNAME` (bot username for deep link generation)

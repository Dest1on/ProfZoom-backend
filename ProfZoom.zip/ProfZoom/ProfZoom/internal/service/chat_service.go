package service

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/errors"
	"ProfZoom/internal/repository"
	"context"
)

type ChatService struct {
	chatRepo repository.ChatRepository
}

func NewChatService(chatRepo repository.ChatRepository) *ChatService {
	return &ChatService{
		chatRepo: chatRepo,
	}
}

// CreateChat создает новый чат
func (s *ChatService) CreateChat(ctx context.Context, chat *entities.Chat) error {
	// Валидация чата
	if err := chat.Validate(); err != nil {
		return err
	}

	// Проверяем не существует ли уже чат
	existing, err := s.chatRepo.GetChatByParticipants(ctx, chat.StudentID, chat.CompanyID, chat.VacancyID)
	if err != nil {
		return err
	}
	if existing != nil {
		return errors.NewAlreadyExistsError("chat")
	}

	return s.chatRepo.CreateChat(ctx, chat)
}

// GetStudentChats возвращает чаты студента
func (s *ChatService) GetStudentChats(ctx context.Context, studentID int64) ([]*entities.Chat, error) {
	return s.chatRepo.GetStudentChats(ctx, studentID)
}

// GetCompanyChats возвращает чаты компании
func (s *ChatService) GetCompanyChats(ctx context.Context, companyID int64) ([]*entities.Chat, error) {
	return s.chatRepo.GetCompanyChats(ctx, companyID)
}

// SendMessage отправляет сообщение в чат
func (s *ChatService) SendMessage(ctx context.Context, message *entities.Message) error {
	// Проверяем что чат существует
	chat, err := s.chatRepo.GetChat(ctx, message.ChatID)
	if err != nil {
		return err
	}
	if chat == nil {
		return errors.ErrChatNotFound
	}

	// Валидация сообщения
	if err := message.Validate(); err != nil {
		return err
	}

	return s.chatRepo.CreateMessage(ctx, message)
}

// GetChatMessages возвращает сообщения чата
func (s *ChatService) GetChatMessages(ctx context.Context, chatID int64, limit, offset int) ([]*entities.Message, error) {
	if limit <= 0 || limit > 100 {
		limit = 50
	}

	return s.chatRepo.GetChatMessages(ctx, chatID, limit, offset)
}

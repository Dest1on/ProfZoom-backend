package service

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/errors"
	"ProfZoom/internal/repository"
	"context"
)

type ProfileService struct {
	userRepo    repository.UserRepository
	studentRepo repository.StudentRepository
	companyRepo repository.CompanyRepository
}

func NewProfileService(
	userRepo repository.UserRepository,
	studentRepo repository.StudentRepository,
	companyRepo repository.CompanyRepository,
) *ProfileService {
	return &ProfileService{
		userRepo:    userRepo,
		studentRepo: studentRepo,
		companyRepo: companyRepo,
	}
}

// CreateStudentProfile создает профиль студента
func (s *ProfileService) CreateStudentProfile(ctx context.Context, profile *entities.StudentProfile) error {
	// Проверяем что пользователь существует
	user, err := s.userRepo.GetUserByID(ctx, profile.ID)
	if err != nil {
		return err
	}
	if user == nil {
		return errors.ErrUserNotFound
	}

	// Проверяем что пользователь может быть студентом
	if !user.HasRole() || user.Role != enums.UserRolePending {
		return errors.ErrInvalidRole
	}

	// Валидация профиля
	if err := profile.Validate(); err != nil {
		return err
	}

	// Обновляем роль пользователя
	if err := s.userRepo.UpdateUserRole(ctx, profile.ID, string(enums.UserRoleStudent)); err != nil {
		return err
	}

	// Создаем профиль студента
	return s.studentRepo.CreateStudentProfile(ctx, profile)
}

// GetStudentProfile возвращает профиль студента
func (s *ProfileService) GetStudentProfile(ctx context.Context, userID int64) (*entities.StudentProfile, error) {
	profile, err := s.studentRepo.GetStudentProfile(ctx, userID)
	if err != nil {
		return nil, err
	}
	if profile == nil {
		return nil, errors.ErrStudentNotFound
	}
	return profile, nil
}

// CreateCompanyProfile создает профиль компании
func (s *ProfileService) CreateCompanyProfile(ctx context.Context, profile *entities.CompanyProfile) error {
	// Проверяем что пользователь существует
	user, err := s.userRepo.GetUserByID(ctx, profile.ID)
	if err != nil {
		return err
	}
	if user == nil {
		return errors.ErrUserNotFound
	}

	// Проверяем что пользователь может быть компанией
	if !user.HasRole() || user.Role != enums.UserRolePending {
		return errors.ErrInvalidRole
	}

	// Валидация профиля
	if err := profile.Validate(); err != nil {
		return err
	}

	// Обновляем роль пользователя
	if err := s.userRepo.UpdateUserRole(ctx, profile.ID, string(enums.UserRoleCompany)); err != nil {
		return err
	}

	// Создаем профиль компании
	return s.companyRepo.CreateCompanyProfile(ctx, profile)
}

// GetCompanyProfile возвращает профиль компании
func (s *ProfileService) GetCompanyProfile(ctx context.Context, userID int64) (*entities.CompanyProfile, error) {
	profile, err := s.companyRepo.GetCompanyProfile(ctx, userID)
	if err != nil {
		return nil, err
	}
	if profile == nil {
		return nil, errors.ErrCompanyNotFound
	}
	return profile, nil
}

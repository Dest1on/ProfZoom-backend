package service

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/errors"
	"ProfZoom/internal/repository"
	"context"
)

type MatchingService struct {
	matchingRepo repository.MatchingRepository
	vacancyRepo  repository.VacancyRepository
	studentRepo  repository.StudentRepository
}

func NewMatchingService(
	matchingRepo repository.MatchingRepository,
	vacancyRepo repository.VacancyRepository,
	studentRepo repository.StudentRepository,
) *MatchingService {
	return &MatchingService{
		matchingRepo: matchingRepo,
		vacancyRepo:  vacancyRepo,
		studentRepo:  studentRepo,
	}
}

// CreateInterest создает отклик студента на вакансию
func (s *MatchingService) CreateInterest(ctx context.Context, interest *entities.Interest) error {
	// Проверяем что студент существует
	student, err := s.studentRepo.GetStudentProfileByID(ctx, interest.StudentID)
	if err != nil {
		return err
	}
	if student == nil || !student.IsActive() {
		return errors.ErrStudentNotFound
	}

	// Проверяем что вакансия существует и активна
	vacancy, err := s.vacancyRepo.GetVacancyByID(ctx, interest.VacancyID)
	if err != nil {
		return err
	}
	if vacancy == nil || !vacancy.IsActive() {
		return errors.ErrVacancyNotFound
	}

	// Проверяем что студент еще не откликался
	existing, err := s.matchingRepo.GetInterest(ctx, interest.StudentID, interest.VacancyID)
	if err != nil {
		return err
	}
	if existing != nil {
		return errors.ErrAlreadyApplied
	}

	// Валидация интереса
	if err := interest.Validate(); err != nil {
		return err
	}

	return s.matchingRepo.CreateInterest(ctx, interest)
}

// GetStudentInterests возвращает отклики студента
func (s *MatchingService) GetStudentInterests(ctx context.Context, studentID int64) ([]*entities.Interest, error) {
	return s.matchingRepo.GetStudentInterests(ctx, studentID)
}

// GetVacancyInterests возвращает отклики на вакансию
func (s *MatchingService) GetVacancyInterests(ctx context.Context, vacancyID int64) ([]*entities.Interest, error) {
	return s.matchingRepo.GetVacancyInterests(ctx, vacancyID)
}

// UpdateInterestStatus обновляет статус отклика
func (s *MatchingService) UpdateInterestStatus(ctx context.Context, interestID int64, status enums.InterestStatus) error {
	return s.matchingRepo.UpdateInterestStatus(ctx, interestID, string(status))
}

// CreateInterview создает собеседование
func (s *MatchingService) CreateInterview(ctx context.Context, interview *entities.Interview) error {
	// Валидация собеседования
	if err := interview.Validate(); err != nil {
		return err
	}

	// Проверяем что студент существует
	student, err := s.studentRepo.GetStudentProfileByID(ctx, interview.StudentID)
	if err != nil {
		return err
	}
	if student == nil {
		return errors.ErrStudentNotFound
	}

	// Проверяем что вакансия существует
	vacancy, err := s.vacancyRepo.GetVacancyByID(ctx, interview.VacancyID)
	if err != nil {
		return err
	}
	if vacancy == nil {
		return errors.ErrVacancyNotFound
	}

	return s.matchingRepo.CreateInterview(ctx, interview)
}

// GetStudentInterviews возвращает собеседования студента
func (s *MatchingService) GetStudentInterviews(ctx context.Context, studentID int64) ([]*entities.Interview, error) {
	return s.matchingRepo.GetStudentInterviews(ctx, studentID)
}

// GetCompanyInterviews возвращает собеседования компании
func (s *MatchingService) GetCompanyInterviews(ctx context.Context, companyID int64) ([]*entities.Interview, error) {
	return s.matchingRepo.GetCompanyInterviews(ctx, companyID)
}

// UpdateInterviewStatus обновляет статус собеседования
func (s *MatchingService) UpdateInterviewStatus(ctx context.Context, interviewID int64, status enums.InterviewStatus) error {
	return s.matchingRepo.UpdateInterviewStatus(ctx, interviewID, string(status))
}

// CreateInterviewSlot создает слот для собеседования
func (s *MatchingService) CreateInterviewSlot(ctx context.Context, slot *entities.InterviewSlot) error {
	// Валидация слота
	if err := slot.Validate(); err != nil {
		return err
	}

	return s.matchingRepo.CreateInterviewSlot(ctx, slot)
}

// GetCompanySlots возвращает слоты компании
func (s *MatchingService) GetCompanySlots(ctx context.Context, companyID int64) ([]*entities.InterviewSlot, error) {
	return s.matchingRepo.GetCompanySlots(ctx, companyID)
}

// GetAvailableSlots возвращает доступные слоты
func (s *MatchingService) GetAvailableSlots(ctx context.Context, companyID int64) ([]*entities.InterviewSlot, error) {
	return s.matchingRepo.GetAvailableSlots(ctx, companyID)
}

// BookInterviewSlot бронирует слот для собеседования
func (s *MatchingService) BookInterviewSlot(ctx context.Context, slotID int64) error {
	return s.matchingRepo.BookInterviewSlot(ctx, slotID)
}

// ReleaseInterviewSlot освобождает слот
func (s *MatchingService) ReleaseInterviewSlot(ctx context.Context, slotID int64) error {
	return s.matchingRepo.ReleaseInterviewSlot(ctx, slotID)
}

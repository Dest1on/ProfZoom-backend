package service

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/errors"
	"ProfZoom/internal/repository"
	"context"
	"crypto/rand"
	"fmt"
	"math/big"
	"time"
)

type AuthService struct {
	otpRepo  repository.UserRepository // Используем для OTP операций
	userRepo repository.UserRepository // Используем для пользователей
}

func NewAuthService(otpRepo repository.UserRepository, userRepo repository.UserRepository) *AuthService {
	return &AuthService{
		otpRepo:  otpRepo,
		userRepo: userRepo,
	}
}

// RequestOTP отправляет OTP код на телефон
func (s *AuthService) RequestOTP(ctx context.Context, phone string) error {
	// Валидация телефона
	if len(phone) < 10 {
		return errors.ErrInvalidPhone
	}

	// Генерируем OTP код (6 цифр)
	code, err := s.generateOTP(6)
	if err != nil {
		return fmt.Errorf("failed to generate OTP: %w", err)
	}

	// Создаем OTP запись (действует 5 минут)
	otp := &entities.OTPCode{
		Phone:     phone,
		Code:      code,
		ExpiresAt: time.Now().Add(5 * time.Minute),
	}

	// Используем OTP репозиторий для создания OTP
	if err := s.otpRepo.CreateOTP(ctx, otp); err != nil {
		return fmt.Errorf("failed to save OTP: %w", err)
	}

	// TODO: Интеграция с SMS сервисом
	fmt.Printf("OTP для %s: %s (действует 5 минут)\n", phone, code)

	return nil
}

// VerifyOTP проверяет OTP код и аутентифицирует пользователя
func (s *AuthService) VerifyOTP(ctx context.Context, phone, code string) (*entities.User, error) {
	// Проверяем OTP через OTP репозиторий
	otp, err := s.otpRepo.GetValidOTP(ctx, phone, code)
	if err != nil {
		return nil, fmt.Errorf("failed to verify OTP: %w", err)
	}
	if otp == nil {
		return nil, errors.ErrInvalidOTP
	}

	// Помечаем OTP как использованный
	if err := s.otpRepo.MarkOTPAsUsed(ctx, otp.ID); err != nil {
		return nil, fmt.Errorf("failed to mark OTP as used: %w", err)
	}

	// Ищем пользователя
	user, err := s.userRepo.GetUserByPhone(ctx, phone)
	if err != nil {
		return nil, fmt.Errorf("failed to get user: %w", err)
	}

	// Если пользователь не существует - создаем нового
	if user == nil {
		user = &entities.User{
			Phone: phone,
			Role:  enums.UserRolePending,
		}
		if err := s.userRepo.CreateUser(ctx, user); err != nil {
			return nil, fmt.Errorf("failed to create user: %w", err)
		}
	}

	return user, nil
}

// UpdateUserRole обновляет роль пользователя
func (s *AuthService) UpdateUserRole(ctx context.Context, userID int64, role enums.UserRole) error {
	if role != enums.UserRoleStudent && role != enums.UserRoleCompany {
		return errors.ErrInvalidRole
	}

	return s.userRepo.UpdateUserRole(ctx, userID, string(role))
}

func (s *AuthService) generateOTP(length int) (string, error) {
	const digits = "0123456789"
	otp := make([]byte, length)

	for i := range otp {
		num, err := rand.Int(rand.Reader, big.NewInt(int64(len(digits))))
		if err != nil {
			return "", err
		}
		otp[i] = digits[num.Int64()]
	}

	return string(otp), nil
}

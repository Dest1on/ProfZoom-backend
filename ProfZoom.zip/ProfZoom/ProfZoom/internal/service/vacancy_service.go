package service

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/errors"
	"ProfZoom/internal/repository"
	"context"
)

type VacancyService struct {
	vacancyRepo repository.VacancyRepository
	companyRepo repository.CompanyRepository
}

func NewVacancyService(vacancyRepo repository.VacancyRepository, companyRepo repository.CompanyRepository) *VacancyService {
	return &VacancyService{
		vacancyRepo: vacancyRepo,
		companyRepo: companyRepo,
	}
}

// CreateVacancy создает новую вакансию
func (s *VacancyService) CreateVacancy(ctx context.Context, vacancy *entities.Vacancy) error {
	// Проверяем что компания существует
	company, err := s.companyRepo.GetCompanyProfileByID(ctx, vacancy.CompanyID)
	if err != nil {
		return err
	}
	if company == nil {
		return errors.ErrCompanyNotFound
	}

	// Валидация вакансии
	if err := vacancy.Validate(); err != nil {
		return err
	}

	// Устанавливаем статус по умолчанию
	vacancy.Status = enums.VacancyStatusActive

	return s.vacancyRepo.CreateVacancy(ctx, vacancy)
}

// GetCompanyVacancies возвращает вакансии компании
func (s *VacancyService) GetCompanyVacancies(ctx context.Context, companyID int64) ([]*entities.Vacancy, error) {
	// Проверяем что компания существует
	company, err := s.companyRepo.GetCompanyProfileByID(ctx, companyID)
	if err != nil {
		return nil, err
	}
	if company == nil {
		return nil, errors.ErrCompanyNotFound
	}

	return s.vacancyRepo.GetCompanyVacancies(ctx, companyID)
}

// GetVacancyFeed возвращает ленту вакансий для студента
func (s *VacancyService) GetVacancyFeed(ctx context.Context, studentID int64, limit, offset int) ([]*entities.Vacancy, error) {
	if limit <= 0 || limit > 50 {
		limit = 20
	}

	return s.vacancyRepo.GetVacancyFeed(ctx, studentID, limit, offset)
}

// UpdateVacancyStatus обновляет статус вакансии
func (s *VacancyService) UpdateVacancyStatus(ctx context.Context, vacancyID int64, status enums.VacancyStatus) error {
	return s.vacancyRepo.UpdateVacancyStatus(ctx, vacancyID, string(status))
}

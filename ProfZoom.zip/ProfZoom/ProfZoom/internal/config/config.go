package config

import (
	"os"
	"strconv"
	"time"
)

// Config представляет конфигурацию приложения
type Config struct {
	// Server settings
	Port        string `mapstructure:"PORT"`
	Environment string `mapstructure:"ENVIRONMENT"`

	// Database settings
	DatabaseURL string `mapstructure:"DATABASE_URL"`

	// Redis settings
	RedisURL      string `mapstructure:"REDIS_URL"`
	RedisPassword string `mapstructure:"REDIS_PASSWORD"`
	RedisDB       int    `mapstructure:"REDIS_DB"`

	// JWT settings
	JWTSecret     string        `mapstructure:"JWT_SECRET"`
	JWTExpiration time.Duration `mapstructure:"JWT_EXPIRATION"`

	// OTP settings
	OTPLength     int           `mapstructure:"OTP_LENGTH"`
	OTPExpiration time.Duration `mapstructure:"OTP_EXPIRATION"`

	// CORS settings
	CORSAllowedOrigins []string `mapstructure:"CORS_ALLOWED_ORIGINS"`

	// Timeout settings
	ReadTimeout  time.Duration `mapstructure:"READ_TIMEOUT"`
	WriteTimeout time.Duration `mapstructure:"WRITE_TIMEOUT"`
	IdleTimeout  time.Duration `mapstructure:"IDLE_TIMEOUT"`
}

// Load загружает конфигурацию из переменных окружения
func Load() *Config {
	return &Config{
		// Server settings
		Port:        getEnv("PORT", "8080"),
		Environment: getEnv("ENVIRONMENT", "development"),

		// Database settings
		DatabaseURL: getEnv("DATABASE_URL", "postgres://user:password@localhost:5432/profzoom?sslmode=disable"),

		// Redis settings
		RedisURL:      getEnv("REDIS_URL", "localhost:6379"),
		RedisPassword: getEnv("REDIS_PASSWORD", ""),
		RedisDB:       getEnvAsInt("REDIS_DB", 0),

		// JWT settings
		JWTSecret:     getEnv("JWT_SECRET", "your-super-secret-jwt-key-change-this-in-production"),
		JWTExpiration: getEnvAsDuration("JWT_EXPIRATION", 24*time.Hour),

		// OTP settings
		OTPLength:     getEnvAsInt("OTP_LENGTH", 6),
		OTPExpiration: getEnvAsDuration("OTP_EXPIRATION", 5*time.Minute),

		// CORS settings
		CORSAllowedOrigins: getEnvAsSlice("CORS_ALLOWED_ORIGINS", []string{"*"}, ","),

		// Timeout settings
		ReadTimeout:  getEnvAsDuration("READ_TIMEOUT", 15*time.Second),
		WriteTimeout: getEnvAsDuration("WRITE_TIMEOUT", 15*time.Second),
		IdleTimeout:  getEnvAsDuration("IDLE_TIMEOUT", 60*time.Second),
	}
}

// IsDevelopment проверяет, является ли окружение разработкой
func (c *Config) IsDevelopment() bool {
	return c.Environment == "development"
}

// IsProduction проверяет, является ли окружение продакшеном
func (c *Config) IsProduction() bool {
	return c.Environment == "production"
}

// Вспомогательные функции для чтения переменных окружения

func getEnv(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

func getEnvAsInt(key string, defaultValue int) int {
	if value := os.Getenv(key); value != "" {
		if intValue, err := strconv.Atoi(value); err == nil {
			return intValue
		}
	}
	return defaultValue
}

func getEnvAsBool(key string, defaultValue bool) bool {
	if value := os.Getenv(key); value != "" {
		if boolValue, err := strconv.ParseBool(value); err == nil {
			return boolValue
		}
	}
	return defaultValue
}

func getEnvAsDuration(key string, defaultValue time.Duration) time.Duration {
	if value := os.Getenv(key); value != "" {
		if duration, err := time.ParseDuration(value); err == nil {
			return duration
		}
	}
	return defaultValue
}

func getEnvAsSlice(key string, defaultValue []string, separator string) []string {
	if value := os.Getenv(key); value != "" {
		return splitString(value, separator)
	}
	return defaultValue
}

func splitString(s string, separator string) []string {
	if s == "" {
		return []string{}
	}

	var result []string
	for _, part := range split(s, separator) {
		if trimmed := trim(part); trimmed != "" {
			result = append(result, trimmed)
		}
	}
	return result
}

// Простые реализации split и trim для избежания зависимостей
func split(s, sep string) []string {
	var parts []string
	start := 0
	for i := 0; i < len(s); i++ {
		if i+len(sep) <= len(s) && s[i:i+len(sep)] == sep {
			parts = append(parts, s[start:i])
			start = i + len(sep)
			i = start - 1
		}
	}
	parts = append(parts, s[start:])
	return parts
}

func trim(s string) string {
	// Удаляем пробелы в начале и конце
	start, end := 0, len(s)
	for start < end && isSpace(s[start]) {
		start++
	}
	for start < end && isSpace(s[end-1]) {
		end--
	}
	return s[start:end]
}

func isSpace(b byte) bool {
	return b == ' ' || b == '\t' || b == '\n' || b == '\r'
}

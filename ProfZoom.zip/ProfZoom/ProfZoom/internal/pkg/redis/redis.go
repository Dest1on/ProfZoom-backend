package redis

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/redis/go-redis/v9"
)

// Connect создает подключение к Redis
func Connect(redisURL, password string, db int) (*redis.Client, error) {
	opts := &redis.Options{
		Addr:     redisURL,
		Password: password,
		DB:       db,
	}

	client := redis.NewClient(opts)

	// Test connection
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := client.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("redis ping failed: %w", err)
	}

	log.Println("Successfully connected to Redis")
	return client, nil
}

// HealthCheck проверяет доступность Redis
func HealthCheck(client *redis.Client) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	return client.Ping(ctx).Err()
}

package types

import (
	"fmt"
	"regexp"
)

// Email представляет email адрес
type Email string

// NewEmail создает новый Email с валидацией
func NewEmail(email string) (Email, error) {
	// Базовая валидация email
	pattern := `^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`
	matched, _ := regexp.MatchString(pattern, email)
	if !matched {
		return "", fmt.Errorf("invalid email format: %s", email)
	}
	return Email(email), nil
}

func (e Email) String() string {
	return string(e)
}

// IsValid проверяет валидность email
func (e Email) IsValid() bool {
	pattern := `^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`
	matched, _ := regexp.MatchString(pattern, string(e))
	return matched
}

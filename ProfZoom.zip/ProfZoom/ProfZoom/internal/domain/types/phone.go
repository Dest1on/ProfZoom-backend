package types

import (
	"fmt"
	"regexp"
)

// Phone представляет телефонный номер
type Phone string

// NewPhone создает новый Phone с валидацией
func NewPhone(phone string) (Phone, error) {
	// Простая валидация российских номеров
	matched, _ := regexp.MatchString(`^\+7\d{10}$`, phone)
	if !matched {
		return "", fmt.Errorf("invalid phone format: %s", phone)
	}
	return Phone(phone), nil
}

func (p Phone) String() string {
	return string(p)
}

// IsValid проверяет валидность номера
func (p Phone) IsValid() bool {
	matched, _ := regexp.MatchString(`^\+7\d{10}$`, string(p))
	return matched
}

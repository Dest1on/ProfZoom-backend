package errors

import "fmt"

// DomainError представляет ошибку доменного уровня
type DomainError struct {
	Code    string `json:"code"`
	Message string `json:"message"`
	Details string `json:"details,omitempty"`
}

func (e DomainError) Error() string {
	return fmt.Sprintf("%s: %s", e.Code, e.Message)
}

// Предопределенные ошибки
var (
	// Аутентификация
	ErrInvalidPhone = DomainError{Code: "INVALID_PHONE", Message: "Invalid phone number format"}
	ErrInvalidOTP   = DomainError{Code: "INVALID_OTP", Message: "Invalid or expired OTP code"}
	ErrUserNotFound = DomainError{Code: "USER_NOT_FOUND", Message: "User not found"}

	// Профили
	ErrStudentNotFound = DomainError{Code: "STUDENT_NOT_FOUND", Message: "Student profile not found"}
	ErrCompanyNotFound = DomainError{Code: "COMPANY_NOT_FOUND", Message: "Company not found"}

	// Вакансии
	ErrVacancyNotFound  = DomainError{Code: "VACANCY_NOT_FOUND", Message: "Vacancy not found"}
	ErrVacancyNotActive = DomainError{Code: "VACANCY_NOT_ACTIVE", Message: "Vacancy is not active"}

	// Матчинг
	ErrAlreadyApplied   = DomainError{Code: "ALREADY_APPLIED", Message: "Already applied to this vacancy"}
	ErrInterestNotFound = DomainError{Code: "INTEREST_NOT_FOUND", Message: "Interest record not found"}

	// Интервью
	ErrInterviewNotFound = DomainError{Code: "INTERVIEW_NOT_FOUND", Message: "Interview not found"}
	ErrInterviewConflict = DomainError{Code: "INTERVIEW_CONFLICT", Message: "Interview time conflict"}
	ErrSlotNotAvailable  = DomainError{Code: "SLOT_NOT_AVAILABLE", Message: "Interview slot is not available"}

	// Чат
	ErrChatNotFound    = DomainError{Code: "CHAT_NOT_FOUND", Message: "Chat not found"}
	ErrMessageNotFound = DomainError{Code: "MESSAGE_NOT_FOUND", Message: "Message not found"}

	// Общие
	ErrAccessDenied = DomainError{Code: "ACCESS_DENIED", Message: "Access denied"}
	ErrInvalidInput = DomainError{Code: "INVALID_INPUT", Message: "Invalid input data"}

	// Валидация
	ErrInvalidWorkHours  = DomainError{Code: "INVALID_WORK_HOURS", Message: "Invalid work hours format"}
	ErrInvalidWorkFormat = DomainError{Code: "INVALID_WORK_FORMAT", Message: "Invalid work format"}
	ErrInvalidSkills     = DomainError{Code: "INVALID_SKILLS", Message: "Skills list is invalid"}
	ErrInvalidRole       = DomainError{Code: "INVALID_ROLE", Message: "Invalid role specified"}
)

// Вспомогательные функции для создания ошибок
func NewValidationError(details string) DomainError {
	return DomainError{
		Code:    "VALIDATION_ERROR",
		Message: "Data validation failed",
		Details: details,
	}
}

func NewNotFoundError(resource string) DomainError {
	return DomainError{
		Code:    "NOT_FOUND",
		Message: resource + " not found",
	}
}

func NewAlreadyExistsError(resource string) DomainError {
	return DomainError{
		Code:    "ALREADY_EXISTS",
		Message: resource + " already exists",
	}
}

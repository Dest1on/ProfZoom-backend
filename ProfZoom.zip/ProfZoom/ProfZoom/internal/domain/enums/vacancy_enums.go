package enums

type VacancyStatus string

const (
	VacancyStatusActive VacancyStatus = "active"
	VacancyStatusPaused VacancyStatus = "paused"
	VacancyStatusClosed VacancyStatus = "closed"
)

type WorkHours string

const (
	WorkHours10_15  WorkHours = "10-15"
	WorkHours15_20  WorkHours = "15-20"
	WorkHours20_30  WorkHours = "20-30"
	WorkHours30Plus WorkHours = "30+"
)

type WorkFormat string

const (
	WorkFormatOffice WorkFormat = "office"
	WorkFormatRemote WorkFormat = "remote"
	WorkFormatHybrid WorkFormat = "hybrid"
)

type SalaryType string

const (
	SalaryTypeHourly SalaryType = "hourly"
	SalaryTypeFixed  SalaryType = "fixed"
	SalaryTypeUnpaid SalaryType = "unpaid"
)

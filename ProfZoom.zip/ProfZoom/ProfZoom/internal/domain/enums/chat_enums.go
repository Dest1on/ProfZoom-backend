package enums

type MessageType string

const (
	MessageTypeText      MessageType = "text"
	MessageTypeFeedback  MessageType = "feedback"
	MessageTypeSystem    MessageType = "system"
	MessageTypeInterview MessageType = "interview"
)

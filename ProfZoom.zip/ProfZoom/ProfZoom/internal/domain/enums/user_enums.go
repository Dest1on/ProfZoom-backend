package enums

type UserRole string

const (
	UserRoleStudent UserRole = "student"
	UserRoleCompany UserRole = "company"
	UserRolePending UserRole = "pending"
)

type StudentStatus string

const (
	StudentStatusActive   StudentStatus = "active"
	StudentStatusPaused   StudentStatus = "paused"
	StudentStatusInactive StudentStatus = "inactive"
)

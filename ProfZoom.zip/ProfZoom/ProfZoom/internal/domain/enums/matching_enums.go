package enums

type InterestStatus string

const (
	InterestStatusPending   InterestStatus = "pending"
	InterestStatusApproved  InterestStatus = "approved"
	InterestStatusRejected  InterestStatus = "rejected"
	InterestStatusCancelled InterestStatus = "cancelled"
)

type InterviewStatus string

const (
	InterviewStatusScheduled InterviewStatus = "scheduled"
	InterviewStatusCompleted InterviewStatus = "completed"
	InterviewStatusCancelled InterviewStatus = "cancelled"
	InterviewStatusNoShow    InterviewStatus = "no_show"
)

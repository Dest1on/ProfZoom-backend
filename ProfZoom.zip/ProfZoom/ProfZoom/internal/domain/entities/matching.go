package entities

import (
	"time"

	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/errors"
)

// Interest представляет отклик студента на вакансию
type Interest struct {
	ID             int64                `json:"id"`
	StudentID      int64                `json:"student_id"`
	VacancyID      int64                `json:"vacancy_id"`
	PreferredHours *enums.WorkHours     `json:"preferred_hours,omitempty"`
	Status         enums.InterestStatus `json:"status"`
	CreatedAt      time.Time            `json:"created_at"`
}

// Interview представляет собеседование
type Interview struct {
	ID        int64                 `json:"id"`
	StudentID int64                 `json:"student_id"`
	VacancyID int64                 `json:"vacancy_id"`
	CompanyID int64                 `json:"company_id"`
	Slot      time.Time             `json:"slot"`
	Status    enums.InterviewStatus `json:"status"`
	CreatedAt time.Time             `json:"created_at"`
}

// InterviewSlot представляет слот для собеседования
type InterviewSlot struct {
	ID          int64     `json:"id"`
	CompanyID   int64     `json:"company_id"`
	SlotStart   time.Time `json:"slot_start"`
	SlotEnd     time.Time `json:"slot_end"`
	IsAvailable bool      `json:"is_available"`
	CreatedAt   time.Time `json:"created_at"`
}

// Методы для Interest
func (i *Interest) IsPending() bool {
	return i.Status == enums.InterestStatusPending
}

func (i *Interest) CanBeCancelled() bool {
	return i.Status == enums.InterestStatusPending
}

func (i *Interest) Validate() error {
	if i.StudentID == 0 {
		return errors.NewValidationError("student ID is required")
	}
	if i.VacancyID == 0 {
		return errors.NewValidationError("vacancy ID is required")
	}
	return nil
}

// Методы для Interview
func (i *Interview) IsScheduled() bool {
	return i.Status == enums.InterviewStatusScheduled
}

func (i *Interview) CanBeCancelled() bool {
	return i.IsScheduled() && time.Until(i.Slot) > time.Hour*24
}

func (i *Interview) Validate() error {
	if i.StudentID == 0 {
		return errors.NewValidationError("student ID is required")
	}
	if i.VacancyID == 0 {
		return errors.NewValidationError("vacancy ID is required")
	}
	if i.CompanyID == 0 {
		return errors.NewValidationError("company ID is required")
	}
	if i.Slot.IsZero() {
		return errors.NewValidationError("interview slot is required")
	}
	if time.Until(i.Slot) < 0 {
		return errors.NewValidationError("interview slot cannot be in the past")
	}
	return nil
}

// Методы для InterviewSlot
func (s *InterviewSlot) Duration() time.Duration {
	return s.SlotEnd.Sub(s.SlotStart)
}

func (s *InterviewSlot) IsValid() bool {
	return s.SlotEnd.After(s.SlotStart) && s.Duration() >= time.Minute*30
}

func (s *InterviewSlot) Validate() error {
	if s.CompanyID == 0 {
		return errors.NewValidationError("company ID is required")
	}
	if !s.IsValid() {
		return errors.NewValidationError("invalid slot time range")
	}
	return nil
}

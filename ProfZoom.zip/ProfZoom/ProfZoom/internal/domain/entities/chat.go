package entities

import (
	"time"

	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/errors"
)

// Chat представляет чат между студентом и компанией
type Chat struct {
	ID        int64     `json:"id"`
	StudentID int64     `json:"student_id"`
	CompanyID int64     `json:"company_id"`
	VacancyID int64     `json:"vacancy_id"`
	CreatedAt time.Time `json:"created_at"`
}

// Message представляет сообщение в чате
type Message struct {
	ID          int64             `json:"id"`
	ChatID      int64             `json:"chat_id"`
	SenderID    int64             `json:"sender_id"`
	SenderRole  enums.UserRole    `json:"sender_role"`
	Content     string            `json:"content"`
	MessageType enums.MessageType `json:"message_type"`
	CreatedAt   time.Time         `json:"created_at"`
}

// Feedback представляет фидбэк по собеседованию
type Feedback struct {
	ID          int64     `json:"id"`
	InterviewID int64     `json:"interview_id"`
	Content     string    `json:"content"`
	Tips        []string  `json:"tips"`
	MiniTasks   []string  `json:"mini_tasks"`
	CreatedBy   int64     `json:"created_by"`
	CreatedAt   time.Time `json:"created_at"`
}

// Методы для Chat
func (c *Chat) Validate() error {
	if c.StudentID == 0 {
		return errors.NewValidationError("student ID is required")
	}
	if c.CompanyID == 0 {
		return errors.NewValidationError("company ID is required")
	}
	if c.VacancyID == 0 {
		return errors.NewValidationError("vacancy ID is required")
	}
	return nil
}

// Методы для Message
func (m *Message) IsFromStudent() bool {
	return m.SenderRole == enums.UserRoleStudent
}

func (m *Message) IsFromCompany() bool {
	return m.SenderRole == enums.UserRoleCompany
}

func (m *Message) Validate() error {
	if m.ChatID == 0 {
		return errors.NewValidationError("chat ID is required")
	}
	if m.SenderID == 0 {
		return errors.NewValidationError("sender ID is required")
	}
	if m.SenderRole == "" {
		return errors.NewValidationError("sender role is required")
	}
	if m.Content == "" {
		return errors.NewValidationError("message content is required")
	}
	if m.MessageType == "" {
		return errors.NewValidationError("message type is required")
	}
	return nil
}

// Методы для Feedback
func (f *Feedback) HasTips() bool {
	return len(f.Tips) > 0
}

func (f *Feedback) HasTasks() bool {
	return len(f.MiniTasks) > 0
}

func (f *Feedback) Validate() error {
	if f.InterviewID == 0 {
		return errors.NewValidationError("interview ID is required")
	}
	if f.Content == "" {
		return errors.NewValidationError("feedback content is required")
	}
	if f.CreatedBy == 0 {
		return errors.NewValidationError("creator ID is required")
	}
	return nil
}

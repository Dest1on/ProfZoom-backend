package entities

import (
	"time"

	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/errors"
)

// User представляет пользователя системы
type User struct {
	ID        int64          `json:"id"`
	Phone     string         `json:"phone"`
	Role      enums.UserRole `json:"role"`
	Email     *string        `json:"email,omitempty"`
	CreatedAt time.Time      `json:"created_at"`
	UpdatedAt time.Time      `json:"updated_at"`
}

// OTPCode представляет код подтверждения
type OTPCode struct {
	ID        int64     `json:"id"`
	Phone     string    `json:"phone"`
	Code      string    `json:"code"`
	ExpiresAt time.Time `json:"expires_at"`
	Used      bool      `json:"used"`
	CreatedAt time.Time `json:"created_at"`
}

// UserProfile представляет базовый профиль пользователя
type UserProfile struct {
	User
}

// StudentProfile представляет профиль студента (наследует User)
type StudentProfile struct {
	UserProfile
	DesiredRoles []string            `json:"desired_roles"`
	Skills       []string            `json:"skills"`
	ProofLinks   []string            `json:"proof_links"`
	HoursPerWeek enums.WorkHours     `json:"hours_per_week"`
	WorkFormat   enums.WorkFormat    `json:"work_format"`
	City         *string             `json:"city,omitempty"`
	Status       enums.StudentStatus `json:"status"`
}

// CompanyProfile представляет профиль компании (наследует User)
type CompanyProfile struct {
	UserProfile
	Name         string `json:"name"`
	ContactEmail string `json:"contact_email"`
}

// Методы для User
func (u *User) IsStudent() bool {
	return u.Role == enums.UserRoleStudent
}

func (u *User) IsCompany() bool {
	return u.Role == enums.UserRoleCompany
}

func (u *User) HasRole() bool {
	return u.Role != enums.UserRolePending
}

func (u *User) Validate() error {
	if u.Phone == "" {
		return errors.ErrInvalidPhone
	}
	if u.Role == "" {
		return errors.ErrInvalidRole
	}
	return nil
}

// Методы для OTPCode
func (o *OTPCode) IsExpired() bool {
	return time.Now().After(o.ExpiresAt)
}

func (o *OTPCode) IsValid() bool {
	return !o.Used && !o.IsExpired()
}

// Методы для StudentProfile
func (s *StudentProfile) HasSkill(skill string) bool {
	for _, sSkill := range s.Skills {
		if sSkill == skill {
			return true
		}
	}
	return false
}

func (s *StudentProfile) AddSkill(skill string) {
	for _, existing := range s.Skills {
		if existing == skill {
			return // Уже есть
		}
	}
	s.Skills = append(s.Skills, skill)
}

func (s *StudentProfile) IsActive() bool {
	return s.Status == enums.StudentStatusActive
}

func (s *StudentProfile) Validate() error {
	if len(s.DesiredRoles) == 0 {
		return errors.NewValidationError("desired roles are required")
	}
	if len(s.Skills) == 0 {
		return errors.NewValidationError("at least one skill is required")
	}
	if len(s.ProofLinks) == 0 {
		return errors.NewValidationError("at least one proof link is required")
	}
	if s.HoursPerWeek == "" {
		return errors.ErrInvalidWorkHours
	}
	if s.WorkFormat == "" {
		return errors.ErrInvalidWorkFormat
	}
	return nil
}

// Методы для CompanyProfile
func (c *CompanyProfile) Validate() error {
	if c.Name == "" {
		return errors.NewValidationError("company name is required")
	}
	if c.ContactEmail == "" {
		return errors.NewValidationError("contact email is required")
	}
	return nil
}

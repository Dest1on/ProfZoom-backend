package entities

import (
	"time"

	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/errors"
	"ProfZoom/internal/domain/value_objects"
)

// Vacancy представляет вакансию
type Vacancy struct {
	ID             int64                      `json:"id"`
	CompanyID      int64                      `json:"company_id"`
	Role           value_objects.WorkRole     `json:"role"`
	Tasks          []string                   `json:"tasks"`
	RequiredSkills []value_objects.Skill      `json:"required_skills"`
	OptionalSkills []value_objects.Skill      `json:"optional_skills"`
	Availability   value_objects.Availability `json:"availability"`
	InternshipInfo value_objects.Internship   `json:"internship_info"`
	Salary         *value_objects.Salary      `json:"salary,omitempty"`
	HasMentor      bool                       `json:"has_mentor"`
	MentorInfo     *string                    `json:"mentor_info,omitempty"`
	Status         enums.VacancyStatus        `json:"status"`
	CreatedAt      time.Time                  `json:"created_at"`
	UpdatedAt      time.Time                  `json:"updated_at"`
}

// Методы для Vacancy
func (v *Vacancy) IsActive() bool {
	return v.Status == enums.VacancyStatusActive
}

func (v *Vacancy) HasRequiredSkill(skill string) bool {
	for _, reqSkill := range v.RequiredSkills {
		if string(reqSkill) == skill {
			return true
		}
	}
	return false
}

func (v *Vacancy) CanApply() bool {
	return v.IsActive() && len(v.RequiredSkills) > 0
}

func (v *Vacancy) Validate() error {
	if v.Role == "" {
		return errors.NewValidationError("role is required")
	}
	if len(v.Tasks) == 0 {
		return errors.NewValidationError("at least one task is required")
	}
	if len(v.RequiredSkills) == 0 {
		return errors.NewValidationError("at least one required skill is required")
	}
	if v.Availability.WorkFormat == "" {
		return errors.ErrInvalidWorkFormat
	}
	return nil
}

func (v *Vacancy) MatchStudentSkills(student *StudentProfile) int {
	matched := 0
	for _, skill := range v.RequiredSkills {
		if student.HasSkill(string(skill)) {
			matched++
		}
	}
	return matched
}

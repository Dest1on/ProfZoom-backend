package value_objects

// Internship представляет информацию о стажировке
type Internship struct {
	Duration   *string `json:"duration,omitempty"` // '4', '8', '12', 'other'
	HasMentor  bool    `json:"has_mentor"`
	MentorInfo *string `json:"mentor_info,omitempty"`
}

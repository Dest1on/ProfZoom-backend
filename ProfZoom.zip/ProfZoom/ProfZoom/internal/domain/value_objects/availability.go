package value_objects

import "ProfZoom/internal/domain/enums"

// Availability представляет доступность работы
type Availability struct {
	HoursPerWeek enums.WorkHours  `json:"hours_per_week"`
	WorkFormat   enums.WorkFormat `json:"work_format"`
	City         *string          `json:"city,omitempty"`
}

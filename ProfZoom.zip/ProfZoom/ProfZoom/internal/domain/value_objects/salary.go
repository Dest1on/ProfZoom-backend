package value_objects

import "ProfZoom/internal/domain/enums"

// Salary представляет информацию о зарплате
type Salary struct {
	Type   enums.SalaryType `json:"type"`             // hourly, fixed, unpaid
	Amount *int             `json:"amount,omitempty"` // ставка в рублях
}

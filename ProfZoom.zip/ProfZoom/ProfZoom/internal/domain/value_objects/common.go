package value_objects

// WorkRole представляет рабочую роль
type WorkRole string

// Skill представляет навык
type Skill string

// URL представляет ссылку
type URL string

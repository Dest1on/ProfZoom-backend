package handler

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/service"

	"github.com/gofiber/fiber/v2"
)

type ChatHandler struct {
	chatService *service.ChatService
}

func NewChatHandler(chatService *service.ChatService) *ChatHandler {
	return &ChatHandler{
		chatService: chatService,
	}
}

type CreateChatRequest struct {
	StudentID int64 `json:"student_id" validate:"required"`
	CompanyID int64 `json:"company_id" validate:"required"`
	VacancyID int64 `json:"vacancy_id" validate:"required"`
}

type SendMessageRequest struct {
	SenderID    int64  `json:"sender_id" validate:"required"`
	SenderRole  string `json:"sender_role" validate:"required,oneof=student company"`
	Content     string `json:"content" validate:"required"`
	MessageType string `json:"message_type" validate:"required,oneof=text feedback system interview"`
}

type ChatMessagesQuery struct {
	Limit  int `query:"limit" default:"50"`
	Offset int `query:"offset" default:"0"`
}

type CreateFeedbackRequest struct {
	Content   string   `json:"content" validate:"required"`
	Tips      []string `json:"tips,omitempty"`
	MiniTasks []string `json:"mini_tasks,omitempty"`
	CreatedBy int64    `json:"created_by" validate:"required"`
}

// CreateChat создает новый чат
// @Summary Создать чат
// @Description Создает новый чат между студентом и компанией
// @Tags chat
// @Accept json
// @Produce json
// @Param request body CreateChatRequest true "Данные чата"
// @Success 201 {object} map[string]interface{}
// @Router /api/v1/chats [post]
func (h *ChatHandler) CreateChat(c *fiber.Ctx) error {
	var req CreateChatRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	chat := &entities.Chat{
		StudentID: req.StudentID,
		CompanyID: req.CompanyID,
		VacancyID: req.VacancyID,
	}

	if err := h.chatService.CreateChat(c.Context(), chat); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"status":  "success",
		"message": "Chat created successfully",
		"chat":    chat,
	})
}

// GetStudentChats возвращает чаты студента
// @Summary Получить чаты студента
// @Description Возвращает список чатов студента
// @Tags chat
// @Produce json
// @Param student_id path int true "ID студента"
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/students/{student_id}/chats [get]
func (h *ChatHandler) GetStudentChats(c *fiber.Ctx) error {
	studentID, err := c.ParamsInt("student_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid student ID",
		})
	}

	chats, err := h.chatService.GetStudentChats(c.Context(), int64(studentID))
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": "Failed to get student chats",
		})
	}

	return c.JSON(fiber.Map{
		"status": "success",
		"chats":  chats,
	})
}

// GetCompanyChats возвращает чаты компании
// @Summary Получить чаты компании
// @Description Возвращает список чатов компании
// @Tags chat
// @Produce json
// @Param company_id path int true "ID компании"
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/companies/{company_id}/chats [get]
func (h *ChatHandler) GetCompanyChats(c *fiber.Ctx) error {
	companyID, err := c.ParamsInt("company_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid company ID",
		})
	}

	chats, err := h.chatService.GetCompanyChats(c.Context(), int64(companyID))
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": "Failed to get company chats",
		})
	}

	return c.JSON(fiber.Map{
		"status": "success",
		"chats":  chats,
	})
}

// SendMessage отправляет сообщение в чат
// @Summary Отправить сообщение
// @Description Отправляет сообщение в указанный чат
// @Tags chat
// @Accept json
// @Produce json
// @Param chat_id path int true "ID чата"
// @Param request body SendMessageRequest true "Данные сообщения"
// @Success 201 {object} map[string]interface{}
// @Router /api/v1/chats/{chat_id}/messages [post]
func (h *ChatHandler) SendMessage(c *fiber.Ctx) error {
	chatID, err := c.ParamsInt("chat_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid chat ID",
		})
	}

	var req SendMessageRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	message := &entities.Message{
		ChatID:      int64(chatID),
		SenderID:    req.SenderID,
		SenderRole:  enums.UserRole(req.SenderRole),
		Content:     req.Content,
		MessageType: enums.MessageType(req.MessageType),
	}

	if err := h.chatService.SendMessage(c.Context(), message); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"status":  "success",
		"message": "Message sent successfully",
		"data":    message,
	})
}

// GetChatMessages возвращает сообщения чата
// @Summary Получить сообщения чата
// @Description Возвращает сообщения чата с пагинацией
// @Tags chat
// @Produce json
// @Param chat_id path int true "ID чата"
// @Param limit query int false "Лимит" default(50)
// @Param offset query int false "Смещение" default(0)
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/chats/{chat_id}/messages [get]
func (h *ChatHandler) GetChatMessages(c *fiber.Ctx) error {
	chatID, err := c.ParamsInt("chat_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid chat ID",
		})
	}

	var query ChatMessagesQuery
	if err := c.QueryParser(&query); err != nil {
		query.Limit = 50
		query.Offset = 0
	}

	if query.Limit <= 0 || query.Limit > 100 {
		query.Limit = 50
	}

	messages, err := h.chatService.GetChatMessages(c.Context(), int64(chatID), query.Limit, query.Offset)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": "Failed to get chat messages",
		})
	}

	return c.JSON(fiber.Map{
		"status":   "success",
		"messages": messages,
		"meta": fiber.Map{
			"limit":  query.Limit,
			"offset": query.Offset,
			"count":  len(messages),
		},
	})
}

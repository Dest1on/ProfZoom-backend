package handler

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/service"
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"
)

type MatchingHandler struct {
	matchingService *service.MatchingService
}

func NewMatchingHandler(matchingService *service.MatchingService) *MatchingHandler {
	return &MatchingHandler{
		matchingService: matchingService,
	}
}

type CreateInterestRequest struct {
	PreferredHours *string `json:"preferred_hours,omitempty"`
}

type CreateInterviewRequest struct {
	Slot time.Time `json:"slot" validate:"required"`
}

type UpdateInterestStatusRequest struct {
	Status string `json:"status" validate:"required,oneof=approved rejected cancelled"`
}

type UpdateInterviewStatusRequest struct {
	Status string `json:"status" validate:"required,oneof=completed cancelled no_show"`
}

// CreateInterest создает отклик студента на вакансию
// @Summary Создать отклик на вакансию
// @Description Создает отклик студента на вакансию (Like)
// @Tags matching
// @Accept json
// @Produce json
// @Param student_id path int true "ID студента"
// @Param vacancy_id path int true "ID вакансии"
// @Param request body CreateInterestRequest true "Данные отклика"
// @Success 201 {object} map[string]interface{}
// @Router /api/v1/students/{student_id}/interests/{vacancy_id} [post]
func (h *MatchingHandler) CreateInterest(c *fiber.Ctx) error {
	studentID, err := c.ParamsInt("student_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid student ID",
		})
	}

	vacancyID, err := c.ParamsInt("vacancy_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid vacancy ID",
		})
	}

	var req CreateInterestRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	interest := &entities.Interest{
		StudentID:      int64(studentID),
		VacancyID:      int64(vacancyID),
		PreferredHours: (*enums.WorkHours)(req.PreferredHours),
		Status:         enums.InterestStatusPending,
	}

	if err := h.matchingService.CreateInterest(c.Context(), interest); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"status":   "success",
		"message":  "Interest created successfully",
		"interest": interest,
	})
}

// GetStudentInterests возвращает отклики студента
// @Summary Получить отклики студента
// @Description Возвращает список откликов студента на вакансии
// @Tags matching
// @Produce json
// @Param student_id path int true "ID студента"
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/students/{student_id}/interests [get]
func (h *MatchingHandler) GetStudentInterests(c *fiber.Ctx) error {
	studentID, err := c.ParamsInt("student_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid student ID",
		})
	}

	interests, err := h.matchingService.GetStudentInterests(c.Context(), int64(studentID))
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": "Failed to get student interests",
		})
	}

	return c.JSON(fiber.Map{
		"status":    "success",
		"interests": interests,
	})
}

// UpdateInterestStatus обновляет статус отклика
// @Summary Обновить статус отклика
// @Description Обновляет статус отклика (approved/rejected/cancelled)
// @Tags matching
// @Accept json
// @Produce json
// @Param interest_id path int true "ID отклика"
// @Param request body UpdateInterestStatusRequest true "Новый статус"
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/interests/{interest_id}/status [put]
func (h *MatchingHandler) UpdateInterestStatus(c *fiber.Ctx) error {
	interestID, err := c.ParamsInt("interest_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid interest ID",
		})
	}

	var req UpdateInterestStatusRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	if err := h.matchingService.UpdateInterestStatus(c.Context(), int64(interestID), enums.InterestStatus(req.Status)); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"status":  "success",
		"message": "Interest status updated successfully",
	})
}

// CreateInterview создает собеседование
// @Summary Создать собеседование
// @Description Создает собеседование между студентом и компанией
// @Tags matching
// @Accept json
// @Produce json
// @Param student_id path int true "ID студента"
// @Param vacancy_id path int true "ID вакансии"
// @Param company_id path int true "ID компании"
// @Param request body CreateInterviewRequest true "Данные собеседования"
// @Success 201 {object} map[string]interface{}
// @Router /api/v1/interviews [post]
func (h *MatchingHandler) CreateInterview(c *fiber.Ctx) error {
	var req CreateInterviewRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	// Получаем ID из query параметров
	studentID, _ := strconv.Atoi(c.Query("student_id"))
	vacancyID, _ := strconv.Atoi(c.Query("vacancy_id"))
	companyID, _ := strconv.Atoi(c.Query("company_id"))

	if studentID == 0 || vacancyID == 0 || companyID == 0 {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Missing required parameters: student_id, vacancy_id, company_id",
		})
	}

	interview := &entities.Interview{
		StudentID: int64(studentID),
		VacancyID: int64(vacancyID),
		CompanyID: int64(companyID),
		Slot:      req.Slot,
		Status:    enums.InterviewStatusScheduled,
	}

	if err := h.matchingService.CreateInterview(c.Context(), interview); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"status":    "success",
		"message":   "Interview created successfully",
		"interview": interview,
	})
}

// GetStudentInterviews возвращает собеседования студента
// @Summary Получить собеседования студента
// @Description Возвращает список собеседований студента
// @Tags matching
// @Produce json
// @Param student_id path int true "ID студента"
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/students/{student_id}/interviews [get]
func (h *MatchingHandler) GetStudentInterviews(c *fiber.Ctx) error {
	studentID, err := c.ParamsInt("student_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid student ID",
		})
	}

	interviews, err := h.matchingService.GetStudentInterviews(c.Context(), int64(studentID))
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": "Failed to get student interviews",
		})
	}

	return c.JSON(fiber.Map{
		"status":     "success",
		"interviews": interviews,
	})
}

// UpdateInterviewStatus обновляет статус собеседования
// @Summary Обновить статус собеседования
// @Description Обновляет статус собеседования (completed/cancelled/no_show)
// @Tags matching
// @Accept json
// @Produce json
// @Param interview_id path int true "ID собеседования"
// @Param request body UpdateInterviewStatusRequest true "Новый статус"
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/interviews/{interview_id}/status [put]
func (h *MatchingHandler) UpdateInterviewStatus(c *fiber.Ctx) error {
	interviewID, err := c.ParamsInt("interview_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid interview ID",
		})
	}

	var req UpdateInterviewStatusRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	if err := h.matchingService.UpdateInterviewStatus(c.Context(), int64(interviewID), enums.InterviewStatus(req.Status)); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"status":  "success",
		"message": "Interview status updated successfully",
	})
}

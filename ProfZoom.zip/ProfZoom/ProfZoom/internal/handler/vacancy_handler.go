package handler

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/value_objects"
	"ProfZoom/internal/service"

	"github.com/gofiber/fiber/v2"
)

type VacancyHandler struct {
	vacancyService *service.VacancyService
}

func NewVacancyHandler(vacancyService *service.VacancyService) *VacancyHandler {
	return &VacancyHandler{
		vacancyService: vacancyService,
	}
}

type CreateVacancyRequest struct {
	Role               string   `json:"role" validate:"required"`
	Tasks              []string `json:"tasks" validate:"required,min=1"`
	RequiredSkills     []string `json:"required_skills" validate:"required,min=1"`
	OptionalSkills     []string `json:"optional_skills,omitempty"`
	HoursPerWeek       []string `json:"hours_per_week" validate:"required,min=1"`
	WorkFormat         string   `json:"work_format" validate:"required,oneof=office remote hybrid"`
	City               *string  `json:"city,omitempty"`
	InternshipDuration *string  `json:"internship_duration,omitempty"`
	SalaryType         *string  `json:"salary_type,omitempty"`
	SalaryAmount       *int     `json:"salary_amount,omitempty"`
	HasMentor          bool     `json:"has_mentor"`
	MentorInfo         *string  `json:"mentor_info,omitempty"`
}

type VacancyFeedQuery struct {
	Limit  int `query:"limit" default:"20"`
	Offset int `query:"offset" default:"0"`
}

// CreateVacancy создает новую вакансию
// @Summary Создать вакансию
// @Description Создает новую вакансию для компании
// @Tags vacancies
// @Accept json
// @Produce json
// @Param company_id path int true "ID компании"
// @Param request body CreateVacancyRequest true "Данные вакансии"
// @Success 201 {object} map[string]interface{}
// @Router /api/v1/companies/{company_id}/vacancies [post]
func (h *VacancyHandler) CreateVacancy(c *fiber.Ctx) error {
	companyID, err := c.ParamsInt("company_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid company ID",
		})
	}

	var req CreateVacancyRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	vacancy := &entities.Vacancy{
		CompanyID:      int64(companyID),
		Role:           value_objects.WorkRole(req.Role),
		Tasks:          req.Tasks,
		RequiredSkills: convertToSkills(req.RequiredSkills),
		OptionalSkills: convertToSkills(req.OptionalSkills),
		Availability: value_objects.Availability{
			HoursPerWeek: enums.WorkHours(req.HoursPerWeek[0]), // берем первый элемент
			WorkFormat:   enums.WorkFormat(req.WorkFormat),
			City:         req.City,
		},
		InternshipInfo: value_objects.Internship{
			Duration:   req.InternshipDuration,
			HasMentor:  req.HasMentor,
			MentorInfo: req.MentorInfo,
		},
		HasMentor:  req.HasMentor,
		MentorInfo: req.MentorInfo,
		Status:     enums.VacancyStatusActive,
	}

	if req.SalaryType != nil {
		vacancy.Salary = &value_objects.Salary{
			Type:   enums.SalaryType(*req.SalaryType),
			Amount: req.SalaryAmount,
		}
	}

	if err := h.vacancyService.CreateVacancy(c.Context(), vacancy); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.Status(fiber.StatusCreated).JSON(fiber.Map{
		"status":  "success",
		"message": "Vacancy created successfully",
		"vacancy": vacancy,
	})
}

// GetCompanyVacancies возвращает вакансии компании
// @Summary Получить вакансии компании
// @Description Возвращает список вакансий компании
// @Tags vacancies
// @Produce json
// @Param company_id path int true "ID компании"
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/companies/{company_id}/vacancies [get]
func (h *VacancyHandler) GetCompanyVacancies(c *fiber.Ctx) error {
	companyID, err := c.ParamsInt("company_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid company ID",
		})
	}

	vacancies, err := h.vacancyService.GetCompanyVacancies(c.Context(), int64(companyID))
	if err != nil {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"status":    "success",
		"vacancies": vacancies,
	})
}

// GetVacancyFeed возвращает ленту вакансий для студента
// @Summary Получить ленту вакансий
// @Description Возвращает ленту вакансий для студента с пагинацией
// @Tags vacancies
// @Produce json
// @Param student_id path int true "ID студента"
// @Param limit query int false "Лимит" default(20)
// @Param offset query int false "Смещение" default(0)
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/students/{student_id}/vacancies/feed [get]
func (h *VacancyHandler) GetVacancyFeed(c *fiber.Ctx) error {
	studentID, err := c.ParamsInt("student_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid student ID",
		})
	}

	var query VacancyFeedQuery
	if err := c.QueryParser(&query); err != nil {
		query.Limit = 20
		query.Offset = 0
	}

	if query.Limit <= 0 || query.Limit > 50 {
		query.Limit = 20
	}

	vacancies, err := h.vacancyService.GetVacancyFeed(c.Context(), int64(studentID), query.Limit, query.Offset)
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
			"error": "Failed to get vacancy feed",
		})
	}

	return c.JSON(fiber.Map{
		"status":    "success",
		"vacancies": vacancies,
		"meta": fiber.Map{
			"limit":  query.Limit,
			"offset": query.Offset,
			"count":  len(vacancies),
		},
	})
}

// UpdateVacancyStatus обновляет статус вакансии
// @Summary Обновить статус вакансии
// @Description Обновляет статус вакансии (active/paused/closed)
// @Tags vacancies
// @Accept json
// @Produce json
// @Param vacancy_id path int true "ID вакансии"
// @Param status body string true "Новый статус" Enums(active, paused, closed)
// @Success 200 {object} map[string]interface{}
// @Router /api/v1/vacancies/{vacancy_id}/status [put]
func (h *VacancyHandler) UpdateVacancyStatus(c *fiber.Ctx) error {
	vacancyID, err := c.ParamsInt("vacancy_id")
	if err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid vacancy ID",
		})
	}

	var req struct {
		Status string `json:"status"`
	}
	if err := c.BodyParser(&req); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": "Invalid request body",
		})
	}

	if err := h.vacancyService.UpdateVacancyStatus(c.Context(), int64(vacancyID), enums.VacancyStatus(req.Status)); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{
			"error": err.Error(),
		})
	}

	return c.JSON(fiber.Map{
		"status":  "success",
		"message": "Vacancy status updated successfully",
	})
}

// Вспомогательная функция для конвертации
func convertToSkills(skills []string) []value_objects.Skill {
	result := make([]value_objects.Skill, len(skills))
	for i, skill := range skills {
		result[i] = value_objects.Skill(skill)
	}
	return result
}

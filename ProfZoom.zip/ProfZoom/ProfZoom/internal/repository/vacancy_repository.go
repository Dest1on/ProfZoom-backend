package repository

import (
	"ProfZoom/internal/domain/entities"
	"context"
)

// VacancyRepository определяет методы для работы с вакансиями
type VacancyRepository interface {
	CreateVacancy(ctx context.Context, vacancy *entities.Vacancy) error
	GetVacancyByID(ctx context.Context, id int64) (*entities.Vacancy, error)
	GetCompanyVacancies(ctx context.Context, companyID int64) ([]*entities.Vacancy, error)
	UpdateVacancy(ctx context.Context, vacancy *entities.Vacancy) error
	UpdateVacancyStatus(ctx context.Context, vacancyID int64, status string) error
	DeleteVacancy(ctx context.Context, vacancyID int64) error

	// Поиск и фильтрация вакансий для студентов
	GetVacanciesForStudent(ctx context.Context, studentID int64, filters *VacancyFilters) ([]*entities.Vacancy, error)
	GetVacancyFeed(ctx context.Context, studentID int64, limit, offset int) ([]*entities.Vacancy, error)
}

// VacancyFilters определяет фильтры для поиска вакансий
type VacancyFilters struct {
	Role           string
	RequiredSkills []string
	WorkFormat     string
	City           string
	SalaryType     string
	HasMentor      *bool
	Status         string
	Limit          int
	Offset         int
}

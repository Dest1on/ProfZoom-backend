package postgres

import (
	"ProfZoom/internal/domain/entities"
	"context"
	"database/sql"
	"fmt"
	"time"
)

type otpRepository struct {
	db *sql.DB
}

func NewOTPRepository(db *sql.DB) *otpRepository {
	return &otpRepository{db: db}
}

func (r *otpRepository) CreateOTP(ctx context.Context, otp *entities.OTPCode) error {
	query := `
		INSERT INTO otp_codes (phone, code, expires_at) 
		VALUES ($1, $2, $3) 
		RETURNING id, created_at
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare create OTP query: %w", err)
	}
	defer stmt.Close()

	err = stmt.QueryRowContext(
		ctx,
		otp.Phone,
		otp.Code,
		otp.ExpiresAt,
	).Scan(&otp.ID, &otp.CreatedAt)

	return err
}

func (r *otpRepository) GetValidOTP(ctx context.Context, phone, code string) (*entities.OTPCode, error) {
	query := `
		SELECT id, phone, code, expires_at, used, created_at 
		FROM otp_codes 
		WHERE phone = $1 AND code = $2 AND expires_at > $3 AND used = false
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get valid OTP query: %w", err)
	}
	defer stmt.Close()

	var otp entities.OTPCode
	err = stmt.QueryRowContext(ctx, phone, code, time.Now()).Scan(
		&otp.ID,
		&otp.Phone,
		&otp.Code,
		&otp.ExpiresAt,
		&otp.Used,
		&otp.CreatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	return &otp, err
}

func (r *otpRepository) MarkOTPAsUsed(ctx context.Context, id int64) error {
	query := `UPDATE otp_codes SET used = true WHERE id = $1`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare mark OTP as used query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx, id)
	return err
}

func (r *otpRepository) CleanExpiredOTPs(ctx context.Context) error {
	query := `DELETE FROM otp_codes WHERE expires_at < $1`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare clean expired OTPs query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx, time.Now())
	return err
}

package postgres

import (
	"ProfZoom/internal/domain/entities"
	"context"
	"database/sql"
	"fmt"

	"time"
)

type matchingRepository struct {
	db *sql.DB
}

func NewMatchingRepository(db *sql.DB) *matchingRepository {
	return &matchingRepository{db: db}
}

// Interest методы
func (r *matchingRepository) CreateInterest(ctx context.Context, interest *entities.Interest) error {
	query := `
		INSERT INTO interests (student_id, vacancy_id, preferred_hours, status) 
		VALUES ($1, $2, $3, $4)
		RETURNING id, created_at
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare create interest query: %w", err)
	}
	defer stmt.Close()

	err = stmt.QueryRowContext(
		ctx,
		interest.StudentID,
		interest.VacancyID,
		interest.PreferredHours,
		interest.Status,
	).Scan(&interest.ID, &interest.CreatedAt)

	return err
}

func (r *matchingRepository) GetInterest(ctx context.Context, studentID, vacancyID int64) (*entities.Interest, error) {
	query := `
		SELECT id, student_id, vacancy_id, preferred_hours, status, created_at
		FROM interests 
		WHERE student_id = $1 AND vacancy_id = $2
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get interest query: %w", err)
	}
	defer stmt.Close()

	var interest entities.Interest
	err = stmt.QueryRowContext(ctx, studentID, vacancyID).Scan(
		&interest.ID,
		&interest.StudentID,
		&interest.VacancyID,
		&interest.PreferredHours,
		&interest.Status,
		&interest.CreatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	return &interest, err
}

func (r *matchingRepository) GetStudentInterests(ctx context.Context, studentID int64) ([]*entities.Interest, error) {
	query := `
		SELECT id, student_id, vacancy_id, preferred_hours, status, created_at
		FROM interests 
		WHERE student_id = $1
		ORDER BY created_at DESC
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare student interests query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, studentID)
	if err != nil {
		return nil, fmt.Errorf("failed to execute student interests query: %w", err)
	}
	defer rows.Close()

	var interests []*entities.Interest
	for rows.Next() {
		var interest entities.Interest
		err := rows.Scan(
			&interest.ID,
			&interest.StudentID,
			&interest.VacancyID,
			&interest.PreferredHours,
			&interest.Status,
			&interest.CreatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan interest: %w", err)
		}
		interests = append(interests, &interest)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return interests, nil
}

func (r *matchingRepository) GetVacancyInterests(ctx context.Context, vacancyID int64) ([]*entities.Interest, error) {
	query := `
		SELECT id, student_id, vacancy_id, preferred_hours, status, created_at
		FROM interests 
		WHERE vacancy_id = $1
		ORDER BY created_at DESC
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare vacancy interests query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, vacancyID)
	if err != nil {
		return nil, fmt.Errorf("failed to execute vacancy interests query: %w", err)
	}
	defer rows.Close()

	var interests []*entities.Interest
	for rows.Next() {
		var interest entities.Interest
		err := rows.Scan(
			&interest.ID,
			&interest.StudentID,
			&interest.VacancyID,
			&interest.PreferredHours,
			&interest.Status,
			&interest.CreatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan interest: %w", err)
		}
		interests = append(interests, &interest)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return interests, nil
}

func (r *matchingRepository) UpdateInterestStatus(ctx context.Context, interestID int64, status string) error {
	query := `UPDATE interests SET status = $1 WHERE id = $2`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update interest status query: %w", err)
	}
	defer stmt.Close()

	result, err := stmt.ExecContext(ctx, status, interestID)
	if err != nil {
		return err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rowsAffected == 0 {
		return sql.ErrNoRows
	}

	return nil
}

// Interview методы
func (r *matchingRepository) CreateInterview(ctx context.Context, interview *entities.Interview) error {
	query := `
		INSERT INTO interviews (student_id, vacancy_id, company_id, slot, status) 
		VALUES ($1, $2, $3, $4, $5)
		RETURNING id, created_at
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare create interview query: %w", err)
	}
	defer stmt.Close()

	err = stmt.QueryRowContext(
		ctx,
		interview.StudentID,
		interview.VacancyID,
		interview.CompanyID,
		interview.Slot,
		interview.Status,
	).Scan(&interview.ID, &interview.CreatedAt)

	return err
}

func (r *matchingRepository) GetInterview(ctx context.Context, id int64) (*entities.Interview, error) {
	query := `
		SELECT id, student_id, vacancy_id, company_id, slot, status, created_at
		FROM interviews 
		WHERE id = $1
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get interview query: %w", err)
	}
	defer stmt.Close()

	var interview entities.Interview
	err = stmt.QueryRowContext(ctx, id).Scan(
		&interview.ID,
		&interview.StudentID,
		&interview.VacancyID,
		&interview.CompanyID,
		&interview.Slot,
		&interview.Status,
		&interview.CreatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	return &interview, err
}

func (r *matchingRepository) GetStudentInterviews(ctx context.Context, studentID int64) ([]*entities.Interview, error) {
	query := `
		SELECT id, student_id, vacancy_id, company_id, slot, status, created_at
		FROM interviews 
		WHERE student_id = $1
		ORDER BY slot ASC
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare student interviews query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, studentID)
	if err != nil {
		return nil, fmt.Errorf("failed to execute student interviews query: %w", err)
	}
	defer rows.Close()

	var interviews []*entities.Interview
	for rows.Next() {
		var interview entities.Interview
		err := rows.Scan(
			&interview.ID,
			&interview.StudentID,
			&interview.VacancyID,
			&interview.CompanyID,
			&interview.Slot,
			&interview.Status,
			&interview.CreatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan interview: %w", err)
		}
		interviews = append(interviews, &interview)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return interviews, nil
}

func (r *matchingRepository) GetCompanyInterviews(ctx context.Context, companyID int64) ([]*entities.Interview, error) {
	query := `
		SELECT id, student_id, vacancy_id, company_id, slot, status, created_at
		FROM interviews 
		WHERE company_id = $1
		ORDER BY slot ASC
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare company interviews query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, companyID)
	if err != nil {
		return nil, fmt.Errorf("failed to execute company interviews query: %w", err)
	}
	defer rows.Close()

	var interviews []*entities.Interview
	for rows.Next() {
		var interview entities.Interview
		err := rows.Scan(
			&interview.ID,
			&interview.StudentID,
			&interview.VacancyID,
			&interview.CompanyID,
			&interview.Slot,
			&interview.Status,
			&interview.CreatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan interview: %w", err)
		}
		interviews = append(interviews, &interview)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return interviews, nil
}

func (r *matchingRepository) UpdateInterviewStatus(ctx context.Context, interviewID int64, status string) error {
	query := `UPDATE interviews SET status = $1 WHERE id = $2`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update interview status query: %w", err)
	}
	defer stmt.Close()

	result, err := stmt.ExecContext(ctx, status, interviewID)
	if err != nil {
		return err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rowsAffected == 0 {
		return sql.ErrNoRows
	}

	return nil
}

// InterviewSlot методы
func (r *matchingRepository) CreateInterviewSlot(ctx context.Context, slot *entities.InterviewSlot) error {
	query := `
		INSERT INTO interview_slots (company_id, slot_start, slot_end, is_available) 
		VALUES ($1, $2, $3, $4)
		RETURNING id, created_at
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare create interview slot query: %w", err)
	}
	defer stmt.Close()

	err = stmt.QueryRowContext(
		ctx,
		slot.CompanyID,
		slot.SlotStart,
		slot.SlotEnd,
		slot.IsAvailable,
	).Scan(&slot.ID, &slot.CreatedAt)

	return err
}

func (r *matchingRepository) GetCompanySlots(ctx context.Context, companyID int64) ([]*entities.InterviewSlot, error) {
	query := `
		SELECT id, company_id, slot_start, slot_end, is_available, created_at
		FROM interview_slots 
		WHERE company_id = $1 AND slot_start > $2
		ORDER BY slot_start ASC
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare company slots query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, companyID, time.Now())
	if err != nil {
		return nil, fmt.Errorf("failed to execute company slots query: %w", err)
	}
	defer rows.Close()

	var slots []*entities.InterviewSlot
	for rows.Next() {
		var slot entities.InterviewSlot
		err := rows.Scan(
			&slot.ID,
			&slot.CompanyID,
			&slot.SlotStart,
			&slot.SlotEnd,
			&slot.IsAvailable,
			&slot.CreatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan interview slot: %w", err)
		}
		slots = append(slots, &slot)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return slots, nil
}

func (r *matchingRepository) GetAvailableSlots(ctx context.Context, companyID int64) ([]*entities.InterviewSlot, error) {
	query := `
		SELECT id, company_id, slot_start, slot_end, is_available, created_at
		FROM interview_slots 
		WHERE company_id = $1 AND is_available = true AND slot_start > $2
		ORDER BY slot_start ASC
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare available slots query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, companyID, time.Now())
	if err != nil {
		return nil, fmt.Errorf("failed to execute available slots query: %w", err)
	}
	defer rows.Close()

	var slots []*entities.InterviewSlot
	for rows.Next() {
		var slot entities.InterviewSlot
		err := rows.Scan(
			&slot.ID,
			&slot.CompanyID,
			&slot.SlotStart,
			&slot.SlotEnd,
			&slot.IsAvailable,
			&slot.CreatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan interview slot: %w", err)
		}
		slots = append(slots, &slot)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return slots, nil
}

func (r *matchingRepository) BookInterviewSlot(ctx context.Context, slotID int64) error {
	query := `UPDATE interview_slots SET is_available = false WHERE id = $1`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare book interview slot query: %w", err)
	}
	defer stmt.Close()

	result, err := stmt.ExecContext(ctx, slotID)
	if err != nil {
		return err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rowsAffected == 0 {
		return sql.ErrNoRows
	}

	return nil
}

func (r *matchingRepository) ReleaseInterviewSlot(ctx context.Context, slotID int64) error {
	query := `UPDATE interview_slots SET is_available = true WHERE id = $1`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare release interview slot query: %w", err)
	}
	defer stmt.Close()

	result, err := stmt.ExecContext(ctx, slotID)
	if err != nil {
		return err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rowsAffected == 0 {
		return sql.ErrNoRows
	}

	return nil
}

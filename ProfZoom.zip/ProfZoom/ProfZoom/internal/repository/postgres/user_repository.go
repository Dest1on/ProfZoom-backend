package postgres

import (
	"ProfZoom/internal/domain/entities"
	"context"
	"database/sql"
	"fmt"
	"time"
)

type userRepository struct {
	db *sql.DB
}

func NewUserRepository(db *sql.DB) *userRepository {
	return &userRepository{db: db}
}

func (r *userRepository) CreateUser(ctx context.Context, user *entities.User) error {
	query := `
		INSERT INTO users (phone, role, email) 
		VALUES ($1, $2, $3) 
		RETURNING id, created_at, updated_at
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare create user query: %w", err)
	}
	defer stmt.Close()

	err = stmt.QueryRowContext(
		ctx,
		user.Phone,
		user.Role,
		user.Email,
	).Scan(&user.ID, &user.CreatedAt, &user.UpdatedAt)

	return err
}

func (r *userRepository) GetUserByID(ctx context.Context, id int64) (*entities.User, error) {
	query := `
		SELECT id, phone, role, email, created_at, updated_at 
		FROM users 
		WHERE id = $1
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get user by ID query: %w", err)
	}
	defer stmt.Close()

	var user entities.User
	err = stmt.QueryRowContext(ctx, id).Scan(
		&user.ID,
		&user.Phone,
		&user.Role,
		&user.Email,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	return &user, err
}

func (r *userRepository) GetUserByPhone(ctx context.Context, phone string) (*entities.User, error) {
	query := `
		SELECT id, phone, role, email, created_at, updated_at 
		FROM users 
		WHERE phone = $1
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get user by phone query: %w", err)
	}
	defer stmt.Close()

	var user entities.User
	err = stmt.QueryRowContext(ctx, phone).Scan(
		&user.ID,
		&user.Phone,
		&user.Role,
		&user.Email,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	return &user, err
}

func (r *userRepository) UpdateUser(ctx context.Context, user *entities.User) error {
	query := `
		UPDATE users 
		SET phone = $1, role = $2, email = $3, updated_at = $4
		WHERE id = $5
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update user query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx,
		user.Phone,
		user.Role,
		user.Email,
		time.Now(),
		user.ID,
	)
	return err
}

func (r *userRepository) UpdateUserRole(ctx context.Context, id int64, role string) error {
	query := `
		UPDATE users 
		SET role = $1, updated_at = $2 
		WHERE id = $3
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update user role query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx, role, time.Now(), id)
	return err
}

package postgres

import (
	"ProfZoom/internal/domain/entities"
	"context"
	"database/sql"
	"fmt"
	"time"
)

type companyRepository struct {
	db *sql.DB
}

func NewCompanyRepository(db *sql.DB) *companyRepository {
	return &companyRepository{db: db}
}

func (r *companyRepository) CreateCompanyProfile(ctx context.Context, profile *entities.CompanyProfile) error {
	query := `
		INSERT INTO companies (user_id, name, contact_email) 
		VALUES ($1, $2, $3)
		RETURNING id, created_at, updated_at
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare create company profile query: %w", err)
	}
	defer stmt.Close()

	err = stmt.QueryRowContext(
		ctx,
		profile.ID, // user_id
		profile.Name,
		profile.ContactEmail,
	).Scan(&profile.ID, &profile.CreatedAt, &profile.UpdatedAt)

	return err
}

func (r *companyRepository) GetCompanyProfile(ctx context.Context, userID int64) (*entities.CompanyProfile, error) {
	query := `
		SELECT 
			c.id, c.user_id, c.name, c.contact_email,
			c.created_at, c.updated_at,
			u.phone, u.role, u.email, u.created_at as user_created, u.updated_at as user_updated
		FROM companies c
		JOIN users u ON c.user_id = u.id
		WHERE c.user_id = $1
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get company profile query: %w", err)
	}
	defer stmt.Close()

	var profile entities.CompanyProfile
	var user entities.User

	err = stmt.QueryRowContext(ctx, userID).Scan(
		&profile.ID,
		&profile.User.ID,
		&profile.Name,
		&profile.ContactEmail,
		&profile.CreatedAt,
		&profile.UpdatedAt,
		&user.Phone,
		&user.Role,
		&user.Email,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	profile.User = user
	return &profile, err
}

func (r *companyRepository) GetCompanyProfileByID(ctx context.Context, companyID int64) (*entities.CompanyProfile, error) {
	query := `
		SELECT 
			c.id, c.user_id, c.name, c.contact_email,
			c.created_at, c.updated_at,
			u.phone, u.role, u.email, u.created_at as user_created, u.updated_at as user_updated
		FROM companies c
		JOIN users u ON c.user_id = u.id
		WHERE c.id = $1
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get company by ID query: %w", err)
	}
	defer stmt.Close()

	var profile entities.CompanyProfile
	var user entities.User

	err = stmt.QueryRowContext(ctx, companyID).Scan(
		&profile.ID,
		&profile.User.ID,
		&profile.Name,
		&profile.ContactEmail,
		&profile.CreatedAt,
		&profile.UpdatedAt,
		&user.Phone,
		&user.Role,
		&user.Email,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	profile.User = user
	return &profile, err
}

func (r *companyRepository) UpdateCompanyProfile(ctx context.Context, profile *entities.CompanyProfile) error {
	query := `
		UPDATE companies 
		SET name = $1, contact_email = $2, updated_at = $3
		WHERE user_id = $4
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update company profile query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx,
		profile.Name,
		profile.ContactEmail,
		time.Now(),
		profile.User.ID,
	)
	return err
}

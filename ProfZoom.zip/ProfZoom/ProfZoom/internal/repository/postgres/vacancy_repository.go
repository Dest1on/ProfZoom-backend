package postgres

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/domain/enums"
	"ProfZoom/internal/domain/value_objects"
	"ProfZoom/internal/repository"
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"
)

type vacancyRepository struct {
	db *sql.DB
}

func NewVacancyRepository(db *sql.DB) *vacancyRepository {
	return &vacancyRepository{db: db}
}

func (r *vacancyRepository) CreateVacancy(ctx context.Context, vacancy *entities.Vacancy) error {
	query := `
		INSERT INTO vacancies (
			company_id, role, tasks, required_skills, optional_skills,
			hours_per_week, work_format, city, internship_duration,
			salary_type, salary_amount, has_mentor, mentor_info, status
		) 
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
		RETURNING id, created_at, updated_at
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare create vacancy query: %w", err)
	}
	defer stmt.Close()

	err = stmt.QueryRowContext(
		ctx,
		vacancy.CompanyID,
		string(vacancy.Role), // Конвертируем WorkRole в string
		pq.Array(vacancy.Tasks),
		pq.Array(convertSkillsToStrings(vacancy.RequiredSkills)),
		pq.Array(convertSkillsToStrings(vacancy.OptionalSkills)),
		string(vacancy.Availability.HoursPerWeek), // Конвертируем WorkHours в string
		string(vacancy.Availability.WorkFormat),   // Конвертируем WorkFormat в string
		vacancy.Availability.City,
		vacancy.InternshipInfo.Duration,
		string(vacancy.Salary.Type), // Конвертируем SalaryType в string
		vacancy.Salary.Amount,
		vacancy.HasMentor,
		vacancy.MentorInfo,
		string(vacancy.Status), // Конвертируем VacancyStatus в string
	).Scan(&vacancy.ID, &vacancy.CreatedAt, &vacancy.UpdatedAt)

	return err
}

func (r *vacancyRepository) GetVacancyByID(ctx context.Context, id int64) (*entities.Vacancy, error) {
	query := `
		SELECT 
			id, company_id, role, tasks, required_skills, optional_skills,
			hours_per_week, work_format, city, internship_duration,
			salary_type, salary_amount, has_mentor, mentor_info, status,
			created_at, updated_at
		FROM vacancies 
		WHERE id = $1
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get vacancy by ID query: %w", err)
	}
	defer stmt.Close()

	return r.scanVacancy(stmt.QueryRowContext(ctx, id))
}

func (r *vacancyRepository) GetCompanyVacancies(ctx context.Context, companyID int64) ([]*entities.Vacancy, error) {
	query := `
		SELECT 
			id, company_id, role, tasks, required_skills, optional_skills,
			hours_per_week, work_format, city, internship_duration,
			salary_type, salary_amount, has_mentor, mentor_info, status,
			created_at, updated_at
		FROM vacancies 
		WHERE company_id = $1
		ORDER BY created_at DESC
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get company vacancies query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, companyID)
	if err != nil {
		return nil, fmt.Errorf("failed to execute get company vacancies query: %w", err)
	}
	defer rows.Close()

	return r.scanVacancies(rows)
}

func (r *vacancyRepository) UpdateVacancy(ctx context.Context, vacancy *entities.Vacancy) error {
	query := `
		UPDATE vacancies 
		SET role = $1, tasks = $2, required_skills = $3, optional_skills = $4,
			hours_per_week = $5, work_format = $6, city = $7, internship_duration = $8,
			salary_type = $9, salary_amount = $10, has_mentor = $11, mentor_info = $12,
			status = $13, updated_at = $14
		WHERE id = $15
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update vacancy query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx,
		string(vacancy.Role),
		pq.Array(vacancy.Tasks),
		pq.Array(convertSkillsToStrings(vacancy.RequiredSkills)),
		pq.Array(convertSkillsToStrings(vacancy.OptionalSkills)),
		string(vacancy.Availability.HoursPerWeek),
		string(vacancy.Availability.WorkFormat),
		vacancy.Availability.City,
		vacancy.InternshipInfo.Duration,
		string(vacancy.Salary.Type),
		vacancy.Salary.Amount,
		vacancy.HasMentor,
		vacancy.MentorInfo,
		string(vacancy.Status),
		time.Now(),
		vacancy.ID,
	)
	return err
}

func (r *vacancyRepository) UpdateVacancyStatus(ctx context.Context, vacancyID int64, status string) error {
	query := `UPDATE vacancies SET status = $1, updated_at = $2 WHERE id = $3`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update vacancy status query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx, status, time.Now(), vacancyID)
	return err
}

func (r *vacancyRepository) DeleteVacancy(ctx context.Context, vacancyID int64) error {
	query := `DELETE FROM vacancies WHERE id = $1`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare delete vacancy query: %w", err)
	}
	defer stmt.Close()

	result, err := stmt.ExecContext(ctx, vacancyID)
	if err != nil {
		return err
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return err
	}

	if rowsAffected == 0 {
		return sql.ErrNoRows
	}

	return nil
}

func (r *vacancyRepository) GetVacanciesForStudent(ctx context.Context, studentID int64, filters *repository.VacancyFilters) ([]*entities.Vacancy, error) {
	queryBuilder := strings.Builder{}
	queryBuilder.WriteString(`
		SELECT DISTINCT
			v.id, v.company_id, v.role, v.tasks, v.required_skills, v.optional_skills,
			v.hours_per_week, v.work_format, v.city, v.internship_duration,
			v.salary_type, v.salary_amount, v.has_mentor, v.mentor_info, v.status,
			v.created_at, v.updated_at
		FROM vacancies v
		WHERE v.status = $1
		AND NOT EXISTS (
			SELECT 1 FROM interests i 
			WHERE i.vacancy_id = v.id AND i.student_id = $2
		)
	`)

	args := []interface{}{"active", studentID} // $1, $2
	paramCount := 3

	conditions := []string{}

	if filters.Role != "" {
		conditions = append(conditions, fmt.Sprintf("v.role = $%d", paramCount))
		args = append(args, filters.Role)
		paramCount++
	}

	if len(filters.RequiredSkills) > 0 {
		conditions = append(conditions, fmt.Sprintf("v.required_skills && $%d", paramCount))
		args = append(args, pq.Array(filters.RequiredSkills))
		paramCount++
	}

	if filters.WorkFormat != "" {
		conditions = append(conditions, fmt.Sprintf("v.work_format = $%d", paramCount))
		args = append(args, filters.WorkFormat)
		paramCount++
	}

	if filters.City != "" {
		conditions = append(conditions, fmt.Sprintf("v.city = $%d", paramCount))
		args = append(args, filters.City)
		paramCount++
	}

	if filters.SalaryType != "" {
		conditions = append(conditions, fmt.Sprintf("v.salary_type = $%d", paramCount))
		args = append(args, filters.SalaryType)
		paramCount++
	}

	if filters.HasMentor != nil {
		conditions = append(conditions, fmt.Sprintf("v.has_mentor = $%d", paramCount))
		args = append(args, *filters.HasMentor)
		paramCount++
	}

	if len(conditions) > 0 {
		queryBuilder.WriteString(" AND ")
		queryBuilder.WriteString(strings.Join(conditions, " AND "))
	}

	queryBuilder.WriteString(" ORDER BY v.created_at DESC")

	if filters.Limit > 0 {
		queryBuilder.WriteString(fmt.Sprintf(" LIMIT $%d", paramCount))
		args = append(args, filters.Limit)
		paramCount++
	}

	if filters.Offset > 0 {
		queryBuilder.WriteString(fmt.Sprintf(" OFFSET $%d", paramCount))
		args = append(args, filters.Offset)
	}

	query := queryBuilder.String()

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare vacancies for student query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to execute vacancies for student query: %w", err)
	}
	defer rows.Close()

	return r.scanVacancies(rows)
}

func (r *vacancyRepository) GetVacancyFeed(ctx context.Context, studentID int64, limit, offset int) ([]*entities.Vacancy, error) {
	filters := &repository.VacancyFilters{
		Limit:  limit,
		Offset: offset,
	}
	return r.GetVacanciesForStudent(ctx, studentID, filters)
}

// Вспомогательные методы
func (r *vacancyRepository) scanVacancies(rows *sql.Rows) ([]*entities.Vacancy, error) {
	var vacancies []*entities.Vacancy

	for rows.Next() {
		vacancy, err := r.scanVacancyFromRows(rows)
		if err != nil {
			return nil, err
		}
		vacancies = append(vacancies, vacancy)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return vacancies, nil
}

func (r *vacancyRepository) scanVacancy(row *sql.Row) (*entities.Vacancy, error) {
	var vacancy entities.Vacancy
	var tasks, requiredSkills, optionalSkills []string
	var hoursPerWeek, workFormat, city, internshipDuration, salaryType, status sql.NullString
	var salaryAmount sql.NullInt64
	var hasMentor bool
	var mentorInfo sql.NullString

	err := row.Scan(
		&vacancy.ID,
		&vacancy.CompanyID,
		&hoursPerWeek, // role теперь сканируем как string
		pq.Array(&tasks),
		pq.Array(&requiredSkills),
		pq.Array(&optionalSkills),
		&hoursPerWeek,
		&workFormat,
		&city,
		&internshipDuration,
		&salaryType,
		&salaryAmount,
		&hasMentor,
		&mentorInfo,
		&status,
		&vacancy.CreatedAt,
		&vacancy.UpdatedAt,
	)

	if err != nil {
		return nil, err
	}

	// Заполняем структуры с конвертацией string -> enum
	vacancy.Tasks = tasks
	vacancy.RequiredSkills = convertToSkills(requiredSkills)
	vacancy.OptionalSkills = convertToSkills(optionalSkills)
	vacancy.Role = value_objects.WorkRole(hoursPerWeek.String) // role
	vacancy.Availability = value_objects.Availability{
		HoursPerWeek: enums.WorkHours(hoursPerWeek.String),
		WorkFormat:   enums.WorkFormat(workFormat.String),
		City:         &city.String,
	}
	vacancy.InternshipInfo = value_objects.Internship{
		Duration:   &internshipDuration.String,
		HasMentor:  hasMentor,
		MentorInfo: &mentorInfo.String,
	}
	if salaryType.Valid {
		amount := int(salaryAmount.Int64)
		vacancy.Salary = &value_objects.Salary{
			Type:   enums.SalaryType(salaryType.String),
			Amount: &amount,
		}
	}
	vacancy.Status = enums.VacancyStatus(status.String)

	return &vacancy, nil
}

func (r *vacancyRepository) scanVacancyFromRows(rows *sql.Rows) (*entities.Vacancy, error) {
	var vacancy entities.Vacancy
	var tasks, requiredSkills, optionalSkills []string
	var role, hoursPerWeek, workFormat, city, internshipDuration, salaryType, status sql.NullString
	var salaryAmount sql.NullInt64
	var hasMentor bool
	var mentorInfo sql.NullString

	err := rows.Scan(
		&vacancy.ID,
		&vacancy.CompanyID,
		&role,
		pq.Array(&tasks),
		pq.Array(&requiredSkills),
		pq.Array(&optionalSkills),
		&hoursPerWeek,
		&workFormat,
		&city,
		&internshipDuration,
		&salaryType,
		&salaryAmount,
		&hasMentor,
		&mentorInfo,
		&status,
		&vacancy.CreatedAt,
		&vacancy.UpdatedAt,
	)

	if err != nil {
		return nil, err
	}

	// Заполняем структуры с конвертацией string -> enum
	vacancy.Tasks = tasks
	vacancy.RequiredSkills = convertToSkills(requiredSkills)
	vacancy.OptionalSkills = convertToSkills(optionalSkills)
	vacancy.Role = value_objects.WorkRole(role.String)
	vacancy.Availability = value_objects.Availability{
		HoursPerWeek: enums.WorkHours(hoursPerWeek.String),
		WorkFormat:   enums.WorkFormat(workFormat.String),
		City:         &city.String,
	}
	vacancy.InternshipInfo = value_objects.Internship{
		Duration:   &internshipDuration.String,
		HasMentor:  hasMentor,
		MentorInfo: &mentorInfo.String,
	}
	if salaryType.Valid {
		amount := int(salaryAmount.Int64)
		vacancy.Salary = &value_objects.Salary{
			Type:   enums.SalaryType(salaryType.String),
			Amount: &amount,
		}
	}
	vacancy.Status = enums.VacancyStatus(status.String)

	return &vacancy, nil
}

func convertToSkills(skills []string) []value_objects.Skill {
	result := make([]value_objects.Skill, len(skills))
	for i, skill := range skills {
		result[i] = value_objects.Skill(skill)
	}
	return result
}

func convertSkillsToStrings(skills []value_objects.Skill) []string {
	result := make([]string, len(skills))
	for i, skill := range skills {
		result[i] = string(skill)
	}
	return result
}

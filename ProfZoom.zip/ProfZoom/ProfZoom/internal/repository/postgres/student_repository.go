package postgres

import (
	"ProfZoom/internal/domain/entities"
	"ProfZoom/internal/repository"
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/lib/pq"
)

type studentRepository struct {
	db *sql.DB
}

func NewStudentRepository(db *sql.DB) *studentRepository {
	return &studentRepository{db: db}
}

func (r *studentRepository) CreateStudentProfile(ctx context.Context, profile *entities.StudentProfile) error {
	query := `
		INSERT INTO students (
			user_id, desired_roles, skills, proof_links, 
			hours_per_week, work_format, city, status
		) 
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
		RETURNING id, created_at, updated_at
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare create student profile query: %w", err)
	}
	defer stmt.Close()

	err = stmt.QueryRowContext(
		ctx,
		profile.ID, // user_id
		pq.Array(profile.DesiredRoles),
		pq.Array(profile.Skills),
		pq.Array(profile.ProofLinks),
		profile.HoursPerWeek,
		profile.WorkFormat,
		profile.City,
		profile.Status,
	).Scan(&profile.ID, &profile.CreatedAt, &profile.UpdatedAt)

	return err
}

func (r *studentRepository) GetStudentProfile(ctx context.Context, userID int64) (*entities.StudentProfile, error) {
	query := `
		SELECT 
			s.id, s.user_id, s.desired_roles, s.skills, s.proof_links,
			s.hours_per_week, s.work_format, s.city, s.status,
			s.created_at, s.updated_at,
			u.phone, u.role, u.email, u.created_at as user_created, u.updated_at as user_updated
		FROM students s
		JOIN users u ON s.user_id = u.id
		WHERE s.user_id = $1
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get student profile query: %w", err)
	}
	defer stmt.Close()

	var profile entities.StudentProfile
	var user entities.User

	err = stmt.QueryRowContext(ctx, userID).Scan(
		&profile.ID,
		&profile.User.ID,
		pq.Array(&profile.DesiredRoles),
		pq.Array(&profile.Skills),
		pq.Array(&profile.ProofLinks),
		&profile.HoursPerWeek,
		&profile.WorkFormat,
		&profile.City,
		&profile.Status,
		&profile.CreatedAt,
		&profile.UpdatedAt,
		&user.Phone,
		&user.Role,
		&user.Email,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	profile.User = user
	return &profile, err
}

func (r *studentRepository) GetStudentProfileByID(ctx context.Context, studentID int64) (*entities.StudentProfile, error) {
	query := `
		SELECT 
			s.id, s.user_id, s.desired_roles, s.skills, s.proof_links,
			s.hours_per_week, s.work_format, s.city, s.status,
			s.created_at, s.updated_at,
			u.phone, u.role, u.email, u.created_at as user_created, u.updated_at as user_updated
		FROM students s
		JOIN users u ON s.user_id = u.id
		WHERE s.id = $1
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare get student by ID query: %w", err)
	}
	defer stmt.Close()

	var profile entities.StudentProfile
	var user entities.User

	err = stmt.QueryRowContext(ctx, studentID).Scan(
		&profile.ID,
		&profile.User.ID,
		pq.Array(&profile.DesiredRoles),
		pq.Array(&profile.Skills),
		pq.Array(&profile.ProofLinks),
		&profile.HoursPerWeek,
		&profile.WorkFormat,
		&profile.City,
		&profile.Status,
		&profile.CreatedAt,
		&profile.UpdatedAt,
		&user.Phone,
		&user.Role,
		&user.Email,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err == sql.ErrNoRows {
		return nil, nil
	}

	profile.User = user
	return &profile, err
}

func (r *studentRepository) UpdateStudentProfile(ctx context.Context, profile *entities.StudentProfile) error {
	query := `
		UPDATE students 
		SET desired_roles = $1, skills = $2, proof_links = $3,
			hours_per_week = $4, work_format = $5, city = $6,
			status = $7, updated_at = $8
		WHERE user_id = $9
	`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update student profile query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx,
		pq.Array(profile.DesiredRoles),
		pq.Array(profile.Skills),
		pq.Array(profile.ProofLinks),
		profile.HoursPerWeek,
		profile.WorkFormat,
		profile.City,
		profile.Status,
		time.Now(),
		profile.User.ID,
	)
	return err
}

func (r *studentRepository) UpdateStudentStatus(ctx context.Context, studentID int64, status string) error {
	query := `UPDATE students SET status = $1, updated_at = $2 WHERE id = $3`

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return fmt.Errorf("failed to prepare update student status query: %w", err)
	}
	defer stmt.Close()

	_, err = stmt.ExecContext(ctx, status, time.Now(), studentID)
	return err
}

func (r *studentRepository) GetStudentsByFilters(ctx context.Context, filters *repository.StudentFilters) ([]*entities.StudentProfile, error) {
	queryBuilder := strings.Builder{}
	queryBuilder.WriteString(`
		SELECT 
			s.id, s.user_id, s.desired_roles, s.skills, s.proof_links,
			s.hours_per_week, s.work_format, s.city, s.status,
			s.created_at, s.updated_at,
			u.phone, u.role, u.email, u.created_at as user_created, u.updated_at as user_updated
		FROM students s
		JOIN users u ON s.user_id = u.id
		WHERE s.status = $1
	`)

	args := []interface{}{"active"} // $1
	paramCount := 2

	conditions := []string{}

	if len(filters.Skills) > 0 {
		conditions = append(conditions, fmt.Sprintf("s.skills && $%d", paramCount))
		args = append(args, pq.Array(filters.Skills))
		paramCount++
	}

	if len(filters.DesiredRoles) > 0 {
		conditions = append(conditions, fmt.Sprintf("s.desired_roles && $%d", paramCount))
		args = append(args, pq.Array(filters.DesiredRoles))
		paramCount++
	}

	if filters.WorkFormat != "" {
		conditions = append(conditions, fmt.Sprintf("s.work_format = $%d", paramCount))
		args = append(args, filters.WorkFormat)
		paramCount++
	}

	if filters.City != "" {
		conditions = append(conditions, fmt.Sprintf("s.city = $%d", paramCount))
		args = append(args, filters.City)
		paramCount++
	}

	if filters.Status != "" {
		conditions = append(conditions, fmt.Sprintf("s.status = $%d", paramCount))
		args = append(args, filters.Status)
		paramCount++
	}

	if len(conditions) > 0 {
		queryBuilder.WriteString(" AND ")
		queryBuilder.WriteString(strings.Join(conditions, " AND "))
	}

	queryBuilder.WriteString(" ORDER BY s.created_at DESC")

	if filters.Limit > 0 {
		queryBuilder.WriteString(fmt.Sprintf(" LIMIT $%d", paramCount))
		args = append(args, filters.Limit)
		paramCount++
	}

	if filters.Offset > 0 {
		queryBuilder.WriteString(fmt.Sprintf(" OFFSET $%d", paramCount))
		args = append(args, filters.Offset)
	}

	query := queryBuilder.String()

	stmt, err := r.db.PrepareContext(ctx, query)
	if err != nil {
		return nil, fmt.Errorf("failed to prepare students by filters query: %w", err)
	}
	defer stmt.Close()

	rows, err := stmt.QueryContext(ctx, args...)
	if err != nil {
		return nil, fmt.Errorf("failed to execute students by filters query: %w", err)
	}
	defer rows.Close()

	var profiles []*entities.StudentProfile
	for rows.Next() {
		var profile entities.StudentProfile
		var user entities.User

		err := rows.Scan(
			&profile.ID,
			&profile.User.ID,
			pq.Array(&profile.DesiredRoles),
			pq.Array(&profile.Skills),
			pq.Array(&profile.ProofLinks),
			&profile.HoursPerWeek,
			&profile.WorkFormat,
			&profile.City,
			&profile.Status,
			&profile.CreatedAt,
			&profile.UpdatedAt,
			&user.Phone,
			&user.Role,
			&user.Email,
			&user.CreatedAt,
			&user.UpdatedAt,
		)
		if err != nil {
			return nil, fmt.Errorf("failed to scan student profile: %w", err)
		}

		profile.User = user
		profiles = append(profiles, &profile)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iteration error: %w", err)
	}

	return profiles, nil
}

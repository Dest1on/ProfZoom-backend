package repository

import (
	"ProfZoom/internal/domain/entities"
	"context"
)

// UserRepository определяет методы для работы с пользователями
type UserRepository interface {
	// Базовые операции с пользователями
	CreateUser(ctx context.Context, user *entities.User) error
	GetUserByID(ctx context.Context, id int64) (*entities.User, error)
	GetUserByPhone(ctx context.Context, phone string) (*entities.User, error)
	UpdateUser(ctx context.Context, user *entities.User) error
	UpdateUserRole(ctx context.Context, id int64, role string) error

	// OTP операции
	CreateOTP(ctx context.Context, otp *entities.OTPCode) error
	GetValidOTP(ctx context.Context, phone, code string) (*entities.OTPCode, error)
	MarkOTPAsUsed(ctx context.Context, id int64) error
	CleanExpiredOTPs(ctx context.Context) error
}

// StudentRepository определяет методы для работы со студентами
type StudentRepository interface {
	CreateStudentProfile(ctx context.Context, profile *entities.StudentProfile) error
	GetStudentProfile(ctx context.Context, userID int64) (*entities.StudentProfile, error)
	GetStudentProfileByID(ctx context.Context, studentID int64) (*entities.StudentProfile, error)
	UpdateStudentProfile(ctx context.Context, profile *entities.StudentProfile) error
	UpdateStudentStatus(ctx context.Context, studentID int64, status string) error

	// Поиск и фильтрация
	GetStudentsByFilters(ctx context.Context, filters *StudentFilters) ([]*entities.StudentProfile, error)
}

// CompanyRepository определяет методы для работы с компаниями
type CompanyRepository interface {
	CreateCompanyProfile(ctx context.Context, profile *entities.CompanyProfile) error
	GetCompanyProfile(ctx context.Context, userID int64) (*entities.CompanyProfile, error)
	GetCompanyProfileByID(ctx context.Context, companyID int64) (*entities.CompanyProfile, error)
	UpdateCompanyProfile(ctx context.Context, profile *entities.CompanyProfile) error
}

// StudentFilters определяет фильтры для поиска студентов
type StudentFilters struct {
	Skills       []string
	DesiredRoles []string
	WorkFormat   string
	City         string
	Status       string
	Limit        int
	Offset       int
}

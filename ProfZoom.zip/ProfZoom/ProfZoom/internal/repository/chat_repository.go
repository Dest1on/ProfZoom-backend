package repository

import (
	"ProfZoom/internal/domain/entities"
	"context"
)

// ChatRepository определяет методы для работы с чатами и сообщениями
type ChatRepository interface {
	// Чат
	CreateChat(ctx context.Context, chat *entities.Chat) error
	GetChat(ctx context.Context, id int64) (*entities.Chat, error)
	GetStudentChats(ctx context.Context, studentID int64) ([]*entities.Chat, error)
	GetCompanyChats(ctx context.Context, companyID int64) ([]*entities.Chat, error)
	GetChatByParticipants(ctx context.Context, studentID, companyID, vacancyID int64) (*entities.Chat, error)

	// Сообщения
	CreateMessage(ctx context.Context, message *entities.Message) error
	GetChatMessages(ctx context.Context, chatID int64, limit, offset int) ([]*entities.Message, error)
	GetMessage(ctx context.Context, id int64) (*entities.Message, error)

	// Фидбэк
	CreateFeedback(ctx context.Context, feedback *entities.Feedback) error
	GetInterviewFeedback(ctx context.Context, interviewID int64) (*entities.Feedback, error)
	GetStudentFeedbacks(ctx context.Context, studentID int64) ([]*entities.Feedback, error)
}

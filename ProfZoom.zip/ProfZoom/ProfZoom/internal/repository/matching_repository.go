package repository

import (
	"ProfZoom/internal/domain/entities"
	"context"
)

// MatchingRepository определяет методы для матчинга и откликов
type MatchingRepository interface {
	// Интересы и отклики
	CreateInterest(ctx context.Context, interest *entities.Interest) error
	GetInterest(ctx context.Context, studentID, vacancyID int64) (*entities.Interest, error)
	GetStudentInterests(ctx context.Context, studentID int64) ([]*entities.Interest, error)
	GetVacancyInterests(ctx context.Context, vacancyID int64) ([]*entities.Interest, error)
	UpdateInterestStatus(ctx context.Context, interestID int64, status string) error

	// Интервью
	CreateInterview(ctx context.Context, interview *entities.Interview) error
	GetInterview(ctx context.Context, id int64) (*entities.Interview, error)
	GetStudentInterviews(ctx context.Context, studentID int64) ([]*entities.Interview, error)
	GetCompanyInterviews(ctx context.Context, companyID int64) ([]*entities.Interview, error)
	UpdateInterviewStatus(ctx context.Context, interviewID int64, status string) error

	// Слоты интервью
	CreateInterviewSlot(ctx context.Context, slot *entities.InterviewSlot) error
	GetCompanySlots(ctx context.Context, companyID int64) ([]*entities.InterviewSlot, error)
	GetAvailableSlots(ctx context.Context, companyID int64) ([]*entities.InterviewSlot, error)
	BookInterviewSlot(ctx context.Context, slotID int64) error
	ReleaseInterviewSlot(ctx context.Context, slotID int64) error
}

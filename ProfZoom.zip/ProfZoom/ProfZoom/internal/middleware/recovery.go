package middleware

import (
	"log"

	"github.com/gofiber/fiber/v2"
)

// Recovery middleware for panic recovery
func Recovery() fiber.Handler {
	return func(c *fiber.Ctx) error {
		defer func() {
			if r := recover(); r != nil {
				log.Printf("Panic recovered: %v", r)

				// Send JSON error response
				c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{
					"error":   "Internal Server Error",
					"message": "Something went wrong",
				})
			}
		}()

		return c.Next()
	}
}

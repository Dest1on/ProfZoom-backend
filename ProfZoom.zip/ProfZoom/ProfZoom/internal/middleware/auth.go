package middleware

import (
	"ProfZoom/internal/domain/errors"
	"strings"

	"github.com/gofiber/fiber/v2"
)

// Auth middleware for JWT authentication
func Auth() fiber.Handler {
	return func(c *fiber.Ctx) error {
		authHeader := c.Get("Authorization")

		if authHeader == "" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"error": "Authorization header is required",
			})
		}

		// Check if it's Bearer token
		parts := strings.Split(authHeader, " ")
		if len(parts) != 2 || parts[0] != "Bearer" {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"error": "Invalid authorization format",
			})
		}

		token := parts[1]

		// TODO: Validate JWT token
		// userID, err := validateJWT(token)
		// if err != nil {
		//     return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
		//         "error": "Invalid token",
		//     })
		// }

		// For now, we'll just parse user ID from token (temporary solution)
		userID, err := parseUserIDFromToken(token)
		if err != nil {
			return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{
				"error": "Invalid token",
			})
		}

		// Set user ID in context
		c.Locals("userID", userID)

		return c.Next()
	}
}

// RoleBasedAuth middleware for role-based authorization
func RoleBasedAuth(allowedRoles ...string) fiber.Handler {
	return func(c *fiber.Ctx) error {
		userRole := c.Locals("userRole")
		if userRole == nil {
			return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
				"error": "Access denied",
			})
		}

		role, ok := userRole.(string)
		if !ok {
			return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
				"error": "Invalid user role",
			})
		}

		// Check if user role is allowed
		allowed := false
		for _, allowedRole := range allowedRoles {
			if role == allowedRole {
				allowed = true
				break
			}
		}

		if !allowed {
			return c.Status(fiber.StatusForbidden).JSON(fiber.Map{
				"error": "Insufficient permissions",
			})
		}

		return c.Next()
	}
}

// Temporary function - replace with real JWT validation
func parseUserIDFromToken(token string) (int64, error) {
	// TODO: Implement real JWT validation
	// This is a temporary implementation
	if token == "" {
		return 0, errors.ErrAccessDenied
	}

	// For development, assume token is the user ID as string
	// In production, use proper JWT validation
	// userID, err := strconv.ParseInt(token, 10, 64)
	// if err != nil {
	//     return 0, errors.ErrAccessDenied
	// }

	return 1, nil // Temporary: return user ID 1 for testing
}

package middleware

import (
	"time"

	"log"

	"github.com/gofiber/fiber/v2"
)

// Logging middleware
func Logging() fiber.Handler {
	return func(c *fiber.Ctx) error {
		start := time.Now()

		// Process request
		err := c.Next()

		// Log after processing
		duration := time.Since(start)

		log.Printf("[%s] %s %s %d %v",
			c.Method(),
			c.Path(),
			c.IP(),
			c.Response().StatusCode(),
			duration,
		)

		return err
	}
}

// StructuredLogging with more details
func StructuredLogging() fiber.Handler {
	return func(c *fiber.Ctx) error {
		start := time.Now()

		err := c.Next()

		duration := time.Since(start)

		// Structured logging
		log.Printf("HTTP Request: method=%s path=%s status=%d duration=%s ip=%s user_agent=%s",
			c.Method(),
			c.Path(),
			c.Response().StatusCode(),
			duration,
			c.IP(),
			c.Get("User-Agent"),
		)

		return err
	}
}

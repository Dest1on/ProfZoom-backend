package main

import (
	"ProfZoom/internal/config"
	"ProfZoom/internal/handler"
	"ProfZoom/internal/middleware"
	logger "ProfZoom/internal/pkg/auth"
	"ProfZoom/internal/pkg/database"
	"ProfZoom/internal/pkg/redis"
	"ProfZoom/internal/repository/postgres"
	"ProfZoom/internal/service"
	"context"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/compress"
)

func main() {
	// Загрузка конфигурации
	cfg := config.Load()

	// Инициализация логгера
	logger := logger.New()
	logger.Info("Starting ProfZoom Backend...")

	// Подключение к PostgreSQL
	db, err := database.Connect(cfg.DatabaseURL)
	if err != nil {
		logger.Fatal("Failed to connect to database: %v", err)
	}
	defer db.Close()

	// Подключение к Redis
	redisClient, err := redis.Connect(cfg.RedisURL, cfg.RedisPassword, cfg.RedisDB)
	if err != nil {
		logger.Fatal("Failed to connect to Redis: %v", err)
	}
	defer redisClient.Close()

	// Инициализация репозиториев
	userRepo := postgres.NewUserRepository(db)
	studentRepo := postgres.NewStudentRepository(db)
	companyRepo := postgres.NewCompanyRepository(db)
	vacancyRepo := postgres.NewVacancyRepository(db)
	matchingRepo := postgres.NewMatchingRepository(db)
	otpRepo := postgres.NewOTPRepository(db)

	// Инициализация сервисов
	authService := service.NewAuthService(otpRepo, userRepo)
	profileService := service.NewProfileService(userRepo, studentRepo, companyRepo)
	vacancyService := service.NewVacancyService(vacancyRepo, companyRepo)
	matchingService := service.NewMatchingService(matchingRepo, vacancyRepo, studentRepo)
	chatService := service.NewChatService(nil) // TODO: добаrepositoryвить chat

	// Инициализация обработчиков
	authHandler := handler.NewAuthHandler(authService)
	vacancyHandler := handler.NewVacancyHandler(vacancyService)
	matchingHandler := handler.NewMatchingHandler(matchingService)
	chatHandler := handler.NewChatHandler(chatService)

	// Создание Fiber приложения
	app := fiber.New(fiber.Config{
		AppName:               "ProfZoom API",
		ReadTimeout:           cfg.ReadTimeout,
		WriteTimeout:          cfg.WriteTimeout,
		IdleTimeout:           cfg.IdleTimeout,
		DisableStartupMessage: cfg.IsProduction(),
	})

	// Global middleware
	app.Use(middleware.CORS)
	app.Use(middleware.Logging())
	app.Use(middleware.Recovery())
	app.Use(compress.New(compress.Config{
		Level: compress.LevelBestSpeed,
	}))

	// Health check route
	app.Get("/health", func(c *fiber.Ctx) error {
		// Check database health
		if err := database.HealthCheck(db); err != nil {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
				"status":  "error",
				"message": "Database unavailable",
			})
		}

		// Check Redis health
		if err := redis.HealthCheck(redisClient); err != nil {
			return c.Status(fiber.StatusServiceUnavailable).JSON(fiber.Map{
				"status":  "error",
				"message": "Redis unavailable",
			})
		}

		return c.JSON(fiber.Map{
			"status":    "success",
			"message":   "ProfZoom API is healthy",
			"timestamp": time.Now().Format(time.RFC3339),
		})
	})

	// API routes
	api := app.Group("/api/v1")

	// Auth routes
	auth := api.Group("/auth")
	auth.Post("/otp/request", authHandler.RequestOTP)
	auth.Post("/otp/verify", authHandler.VerifyOTP)
	auth.Put("/users/:user_id/role", authHandler.UpdateRole)

	// Vacancy routes
	vacancies := api.Group("/vacancies")
	vacancies.Post("/companies/:company_id/vacancies", vacancyHandler.CreateVacancy)
	vacancies.Get("/companies/:company_id/vacancies", vacancyHandler.GetCompanyVacancies)
	vacancies.Get("/students/:student_id/vacancies/feed", vacancyHandler.GetVacancyFeed)
	vacancies.Put("/:vacancy_id/status", vacancyHandler.UpdateVacancyStatus)

	// Matching routes
	matching := api.Group("/matching")
	matching.Post("/students/:student_id/interests/:vacancy_id", matchingHandler.CreateInterest)
	matching.Get("/students/:student_id/interests", matchingHandler.GetStudentInterests)
	matching.Put("/interests/:interest_id/status", matchingHandler.UpdateInterestStatus)
	matching.Post("/interviews", matchingHandler.CreateInterview)
	matching.Get("/students/:student_id/interviews", matchingHandler.GetStudentInterviews)
	matching.Put("/interviews/:interview_id/status", matchingHandler.UpdateInterviewStatus)

	// Chat routes
	chats := api.Group("/chats")
	chats.Post("", chatHandler.CreateChat)
	chats.Get("/students/:student_id/chats", chatHandler.GetStudentChats)
	chats.Get("/companies/:company_id/chats", chatHandler.GetCompanyChats)
	chats.Post("/:chat_id/messages", chatHandler.SendMessage)
	chats.Get("/:chat_id/messages", chatHandler.GetChatMessages)

	// Protected routes example (with auth middleware)
	protected := api.Group("/protected", middleware.Auth())
	protected.Get("/profile", func(c *fiber.Ctx) error {
		userID := c.Locals("userID")
		return c.JSON(fiber.Map{
			"message": "This is a protected route",
			"user_id": userID,
		})
	})

	// 404 Handler
	app.Use(func(c *fiber.Ctx) error {
		return c.Status(fiber.StatusNotFound).JSON(fiber.Map{
			"error":   "Not Found",
			"message": "The requested resource was not found",
		})
	})

	// Graceful shutdown
	shutdown := make(chan os.Signal, 1)
	signal.Notify(shutdown, os.Interrupt, syscall.SIGTERM)

	// Start server in goroutine
	go func() {
		logger.Info("🚀 Server starting on port %s", cfg.Port)
		if err := app.Listen(":" + cfg.Port); err != nil {
			logger.Fatal("Failed to start server: %v", err)
		}
	}()

	// Wait for interrupt signal
	<-shutdown
	logger.Info("🛑 Shutting down server...")

	// Create shutdown context with timeout
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	// Shutdown server
	if err := app.ShutdownWithContext(ctx); err != nil {
		logger.Error("Failed to shutdown server gracefully: %v", err)
	}

	// Close database connections
	if err := db.Close(); err != nil {
		logger.Error("Failed to close database connection: %v", err)
	}

	redisClient.Close()

	logger.Info("✅ Server stopped gracefully")
}
